
var demo = {};
var board, lineboard, wagesBoard;
var rangeInitializer = 0

//X Axis Value Conversion
var xValConvert = function (x) {
    var min = 0;
    var max = 12;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 12;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//Y Axis Value Conversion
var yStaticValConvert = function (y) {
    var min = 0;
    var max = 60000;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 60;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};

//Y Axis Value Conversion
var yValConvert = function (y) {
    var min = 0;
    var max = rangeInitializer * 1000;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = rangeInitializer;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};

demo.Init = function () {

    board = JXG.JSXGraph.initBoard('jxgboxFixed', {
        boundingbox: [0, 60, 12, 0],
        axis: false,
        grid: false,
        withLabel: true,
        showCopyright: false,
        keepaspectratio: false,
        showNavigation: false

    });
    board.create('axis', [[0, 0], [60, 0]], {
        firstArrow: false,
        lastArrow: false,
        withLabel: false,
        name: 'X',
        straightFirst: false,
        straightLast: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        label: {
            position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, 10]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: 'grey',
            majorHeight: 0}
    });
    board.create('axis', [[0, 0], [0, 60]],
            {name: 'y',
                withLabel: false,
                straightFirst: false,
                straightLast: false,
                firstArrow: false,
                lastArrow: false,
                strokeColor: '#606060',
                strokeWidth: 2,
                label: {
                    position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [10, 10]   // (in pixels)
                },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: 'grey',
                    majorHeight: 0}
            });

   
    demo.part2UpdateGraph();
      $("#jxgbox > svg").attr("desc", "This is a Lifecycle Consumption Model graph");
    $("#jxgbox > svg").attr("title", "Graph");
    this.sliderSelection();

};
demo.part1GraphInitialize=function(){
     lineboard = JXG.JSXGraph.initBoard('jsxGraph_01', {
        boundingbox: [0, rangeInitializer, 60, 0],
        axis: false,
        grid: false,
        withLabel: true,
        showCopyright: false,
        keepaspectratio: false,
        showNavigation: false

    });
    lineboard.create('axis', [[0, 0], [60, 0]], {
        firstArrow: false,
        lastArrow: false,
        withLabel: false,
        name: 'X',
        straightFirst: false,
        straightLast: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        label: {
            position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, 10]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: 'grey',
            majorHeight: 0}
    });
    lineboard.create('axis', [[0, 0], [0, rangeInitializer]],
            {name: 'y',
                withLabel: false,
                straightFirst: false,
                straightLast: false,
                firstArrow: false,
                lastArrow: false,
                strokeColor: '#606060',
                strokeWidth: 2,
                label: {
                    position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [10, 10]   // (in pixels)
                },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: 'grey',
                    majorHeight: 0}
            });


    wagesBoard = JXG.JSXGraph.initBoard('jsxGraph_03', {
        boundingbox: [0, rangeInitializer, 12, 0],
        axis: false,
        grid: false,
        withLabel: true,
        showCopyright: false,
        keepaspectratio: false,
        showNavigation: false

    });
    wagesBoard.create('axis', [[0, 0], [rangeInitializer, 0]], {
        firstArrow: false,
        lastArrow: false,
        withLabel: false,
        name: 'X',
        straightFirst: false,
        straightLast: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        label: {
            position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, 10]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: 'grey',
            majorHeight: 0}
    });
    wagesBoard.create('axis', [[0, 0], [0, rangeInitializer]],
            {name: 'y',
                withLabel: false,
                straightFirst: false,
                straightLast: false,
                firstArrow: false,
                lastArrow: false,
                strokeColor: '#606060',
                strokeWidth: 2,
                label: {
                    position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [10, 10]   // (in pixels)
                },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: 'grey',
                    majorHeight: 0}
            });
             demo.part1UpdateWagesGraph();
};


demo.sliderSelection = function () {
    $("input[id^='ex']").each(function () {
        $(this).initiateSlider();
    });

};

$.fn.initiateSlider = function () {
    var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
            var vElmValue = value;
            vElmValue = (demo.getType(oThisElm.attr("data-slider-step")) === "float") ? Number(value).toFixed(2) : vElmValue;
            oThisElm.parent().parent().find(".rhinput").val(vElmValue);
            return 'Current value: ' + value;

        }
    });
     $("input[id^='ex']").slider().off().on('slideStop', function (ev, k) {
       macroModels.prototype.updatePart2Table();
        demo.clearAll();
      });

};

demo.part1UpdateWagesGraph = function () {
     
lineboard.create('curve', [lineGraphX, lineGraphY], {strokeColor: '#008000', strokeWidth: 1.5, fixed: true,highlight:false,  label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-180, 20] // (in pixels)
        }});
    for (var i = 0; i < part1Wages.length; i++) {
        wagesBoard.create('line', [[function () {
                    return  i + 0.5;
                }, 0.1], [function () {
                    return  i + 0.5;
                }, function () {
                    return yValConvert(part1Wages[i]);
                }]], {
            straightFirst: false,
            straightLast: false,
            strokeWidth: 65,
             strokeColor: '#008000',
            highlight: false,
            label: {offset: [10, 30]},
            fixed: true});
        wagesBoard.create('line', [[function () {
                    return  i + 0.5;
                }, 0.1], [function () {
                    return  i + 0.5;
                }, function () {
                    return yValConvert(part1Consumption[i]);
                }]], {
            straightFirst: false,
            straightLast: false,
            strokeWidth: 65,
             strokeColor: 'red',
            highlight: false,
            label: {offset: [10, 30]},
            fixed: true});
    }
    
};

demo.part2UpdateGraph = function () {

    for (var i = 0; i < part2Wages.length; i++) {
        board.create('line', [[function () {
                    return  i + 0.5;
                }, 0.1], [function () {
                    return  i + 0.5;
                }, function () {
                    return yStaticValConvert(part2Consumption[i]);
                }]], {
            straightFirst: false,
            straightLast: false,
            strokeWidth: 65,
            class: "redLine",
            strokeColor: 'red',
            highlight: false,
            label: {offset: [10, 30]},
            fixed: true})

        board.create('line', [[function () {
                    return  i + 0.5;
                }, 0.1], [function () {
                    return  i + 0.5;
                }, function () {
                    return yStaticValConvert(part2Wages[i]);
                }]], {
            straightFirst: false,
            straightLast: false,
            strokeWidth: 65,
            strokeColor: '#008000',
            highlight: false,
            label: {offset: [10, 30]},
            fixed: true});

    }
};
demo.clearAll = function () {
    $("#jxgboxFixed svg line[stroke='#008000'],#jxgboxFixed svg line[stroke='red']").remove();
    demo.part2UpdateGraph();
  }
demo.getType = function (input) {
    var m = (/[\d]+(\.[\d]+)?/).exec(input);
    if (m) {
        // Check if there is a decimal place
        if (m[1]) {
            return 'float';
        }
        else {
            return 'int';
        }
    }
    return 'string';
}