/**
 * Main _Contructor Function of this Application.
 */
function macroModels() {
    this._xmlFileName = "Activity.xml";
    this._xmlFilePath = "./xml/";
    this._xmlObject = null;
    this._activityTitle = null;
}

/**
 * Function Loads the Macromodel Activity XML from the configured parameters in _Constructor.
 * The Function Store the XML Object in the Defined Variable in _Constructor.
 */
macroModels.prototype.LoadXML = function () {
    //Loading XML File.
    this._xmlObject = loadXMLDoc(this._xmlFilePath + this._xmlFileName);
    //Parsing XML String.
    this._xmlObject = parseXMLString(this._xmlObject);
    //The Main DOM is been added in Object.
    this._xmlObject = this._xmlObject.getElementsByTagName("activity")[0];
    this.GenerateHTML();
    this.controlTab();
};

window.addEventListener("orientationchange", function () {
    $("input").blur();
}, false);
/**
 * [[Description]]
 */


macroModels.prototype.GenerateHTML = function () {
    // stri  
    //Title Name
    this._activityTitle = this._xmlObject.getElementsByTagName("heading")[0].childNodes[0].nodeValue;
    $("title").html(this._activityTitle);
    $(".modelTitle a").html(this._activityTitle);
    $(".questionHolder p").html(this._xmlObject.getElementsByTagName("question")[0].childNodes[0].nodeValue);
    var _activityTabsCount = this._xmlObject.getElementsByTagName("section").length;

    for (i = 0; i < _activityTabsCount; i++) {
        $(".nav li:eq(" + i + ") a").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "content") {
            $(".tab-pane :eq(" + i + ") p").html(this._xmlObject.getElementsByTagName("section")[0].childNodes[1].textContent);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContent") {
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[i].childNodes[1].textContent);

            var xmlObj = this._xmlObject.getElementsByTagName("section")[i];
            var sliderObjCounter = 0;
            var quesparameter = '';
            $(xmlObj).find("rangeOptions").find("options").each(function (e) {

                quesparameter += '<div class="rangeShell"><div class="rholder" aria-labeldby = "' + $(this).find("title").text() + '"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled value="' + $(this).find("value").text() + '" class="rhinput" title = "Parameters ' + $(this).find("title").text() + 'slider"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + Number($(this).find("value").text()) + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput" title = "first input value">' + $(this).find("value").text() + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("#" + this._xmlObject.getElementsByTagName("section")[i].getAttribute("id") + " ." + $(xmlObj).find("rangeOptions").attr("id")).html(quesparameter);

        }
    }

    setTimeout(function () {
        $("#jxgbox_jxgBoard1_infobox").text("");
        $("svg").before("<span class = 'hiddenText1'>This is a Lifecycle Consumption Model graph</span>");
        $("svg").attr("focusable", "false");
        $("li > a").blur();
        $(".tab-pane").attr("role", "alert");
    }, 200)
    setTimeout(function () {

        $(".part2_graph").after('<div class="spanHolder1"><span class="firstX2">20</span><span class="middleX">Age</span><span class="lastX">80</span></div>');
    }, 2000);
    this.part1SlideInitialize();
    this.Event(false);
};
macroModels.prototype.controlTab = function () {
    $("ul > li.active").children().attr("tabindex", "-1");
    var that = this;
    var nextClickCount = 0;
    $("ul > li").on("click", function () {
        if ($(this).hasClass("slider")) {
            if (that._activitySliderCount < 3) {
                that._activitySliderCount++;
            } else {
                that._activitySliderCount = 0;
            }
            that.part1SlideInitialize();
            nextClickCount = 0;
            $(".next").show();
        }

        $(".next").off("click").on("click", function () {
            nextClickCount++;
            if (nextClickCount > 1)
                $(this).hide();
            if (nextClickCount == 1) {

                $(".questionSet").eq(1).attr("role", "alert");
                $(".spanHolderVertical").hide();
                $(".spanHolder").hide();
            }
            if (nextClickCount == 2) {
                $(".spanHolderVertical").show();
                $(".spanHolder").hide();
                $(".questionSet").eq(2).attr("role", "alert");
            }
            if (nextClickCount == 0) {
                $(".spanHolderVertical").show();
                $(".spanHolder").show();
            }


            $(".questionSet").hide();
            $(".questionSet").eq(nextClickCount).show();
        });
        setTimeout(function () {
            if ($("ul > li.active").children().attr("aria-expanded") == "true") {
                $("ul > li").children().removeAttr("tabindex");
                $("ul > li.active").children().attr("tabindex", "-1");
                if ($("ul > li.active").children().attr("href") == "#Graph02") {
                    setTimeout(function () {
                        $("#jxgbox_jxgBoard1_infobox").text("");
                        $("svg").before("<span class = 'hiddenText1'>This is a Lifecycle Consumption Model graph</span>");
                        $("svg").attr("focusable", "false");

                    }, 200)
                    $(".spanHolderVertical").hide();
                    $(".spanHolder1").hide();
                    $(".spanHolder").hide();
                }
                if ($("ul > li.active").children().attr("href") == "#Graph01") {
                    $(".spanHolderVertical").show();
                    setTimeout(function () {
                        $("#jxgbox_jxgBoard1_infobox").text("");
                        $("svg").before("<span class = 'hiddenText1'>This is a Lifecycle Consumption Model graph</span>");
                        $("svg").attr("focusable", "false");

                    }, 200)
                }
                else {
                    $(".spanHolderVertical").hide();
                    $(".spanHolder").hide();
                }
            }

        }, 250);
        // 
        setTimeout(function () {
            $(".tab-pane").attr("role", "alert");
        }, 500);
        $("#jxgboxFixed").removeClass('elementShow').addClass('elementHide');
        $("#table").removeClass('elementHide').addClass('elementShow');
        $(".param").attr("tabIndex", "0").focus();
    });
};
macroModels.prototype.part1SlideInitialize = function () {
    var string = "";
    var that = this;
    var labelArray = ["40000", "3000000", "125000", "60000"];
     var welathEnd = '<tr><td>T</td><td>Wealth at end of life</td><td class="wealthEnd"></td></tr>';
    var xmlObj = that._xmlObject.getElementsByTagName("section")[1];
    var wagesArray = [];
    var consumptionArray = [];
    var obj = Math.floor((Math.random() * $(xmlObj).find("options").find("option").length) + 0)
    $(xmlObj).find("options").each(function (e) {
        $(this).find("option").eq(obj).find("set").each(function (e) {
            string += "<section class='questionSet'>";
            if ($(this).attr("type") !== "table") {
                string += "<div id='jsxGraph_0" + (e + 1) + "' class='graph01'></div><div class='spanHolder_1'><span class='firstX2'>20</span><span class='middleX'>Age</span><span class='lastX'>80</span></div><div class='clearfix'></div><p>" + $(this).find("description").text() + "</p>";
            }
            else {
                wagesArray = $(this).find("wages").text().split(",");
                consumptionArray = $(this).find("consumption").text().split(",");
                string += "<div class='part1Table'></div><p>" + $(this).find("description").text() + "</p>";
            }
            string += "</section>";
        });
        rangeInitializer = Number($(this).find("option").eq(obj).attr("range"));
    });

    $("#Graph01 .sliderCont").html(string);

    $("#Graph01 .part1Table").html(macroModels.prototype.part1CreateTable(wagesArray, consumptionArray));
     $("#Graph01 .part1Table tbody").append(welathEnd);
    $("#Graph01 .sliderCont .questionSet").eq(0).show();
    $(".horz6").html(labelArray[obj]);
    macroModels.prototype.tableInputBindEvent();
    macroModels.prototype.updatePart1Table();
    demo.part1GraphInitialize();
};
/**
 * The Application On Ready Initialise.
 * Create the Main Object Class.
 */

macroModels.prototype.Event = function (bool) {
    var parameter = false;
    var that = this;

    //question parameter click && parameter back click
    $(".param,.introback").off("click").on("click", function () {

        parameter = !parameter;
        // Can add another method and properties
        if (parameter) {
            $(".param").text("Go To Table");

            $(".spanHolderVertical").show();
            $(".spanHolder1").show();
            $("#table").removeClass('elementShow').addClass('elementHide');
            $("#jxgboxFixed").removeClass('elementHide').addClass('elementShow');
            $(".introback").attr("tabIndex", "0").focus().hide();
            $("#jxgboxFixed").removeAttr("aria-hidden", "false");
            $(".param").show();
            setTimeout(function () {
                $("#jxgboxFixed").attr("role", "alert")
            }, 250);
        } else {
            $(".introback").text("Go To Graph")
            $(".spanHolderVertical").hide();
            $(".spanHolder1").hide();
            $("#jxgboxFixed").removeClass('elementShow').addClass('elementHide');
            $("#table").removeClass('elementHide').addClass('elementShow');
            $(".param").attr("tabIndex", "0").focus().hide();
            $(".introback").show();
            setTimeout(function () {
                $("#table").attr("role", "alert")
            }, 250);
        }
    });

    macroModels.prototype.part2CreateTable();
}
macroModels.prototype.part2CreateTable = function () {
    var table = '';
    var header = ['Period', 'Age', 'Wealth', 'Interest', 'Wages', 'Consumption'];
    var startYear = 15;
    var welathEnd = '<tr><td>T</td><td>Wealth at end of life</td><td class="wealthEnd"></td></tr>';
    if ($('#table').find("table").length > 0) {
        table = $('#table').find("table");
    } else {
        table = $('<table></table>');
    }

    for (var i = 0; i <= 12; i++) {
        var row = $('<tr></tr>');
        for (var j = 0; j < 6; j++) {
            var column;

            if (i === 0) {
                column = $('<th></th>').text(header[j]);
            }
            else {
                if (j === 0) {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text(i);
                }
                else if (j === 1) {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text((startYear) + "-" + (startYear + 4));
                }
                else if (j === 4) {
                    var value = (i < 10) ? 30000 : 0;
                    column = $('<td class="' + header[j].toLowerCase() + '"><input type="text" value="' + value + '" title = "Wages"/></td>');
                }
                else {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text(0);
                }
            }
            table.append(row);
            row.append(column);
        }

        startYear = startYear + 5;
    }
    $('#table').html(table);
    $("#Graph02 #table tbody").append(welathEnd);
    macroModels.prototype.tableInputBindEvent();
    macroModels.prototype.updatePart2Table();
};
macroModels.prototype.part1CreateTable = function (wages, cons) {
    var table = '';
    var header = ['Period', 'Age', 'Wealth', 'Interest', 'Wages', 'Consumption'];
    
    var startYear = 15;

    table = $('<table></table>');

    for (var i = 0; i <= 12; i++) {
        var row = $('<tr></tr>');
        for (var j = 0; j < 6; j++) {
            var column;

            if (i === 0) {
                column = $('<th></th>').text(header[j]);
            }
            else {
                if (j === 0) {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text(i);
                }
                else if (j === 1) {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text((startYear) + "-" + (startYear + 4));
                }
                else if (j === 4) {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text($.trim(wages[i - 1]));
                }
                else if (j === 5) {
                    column = $('<td class="' + header[j].toLowerCase() + '"><input type="text" title = "Consumption" value="' + 0 + '"></td>');
                }
                else {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text(0);
                }
            }
            table.append(row);
            row.append(column);
        }

        startYear = startYear + 5;
    }
    return table;

};
macroModels.prototype.tableInputBindEvent = function () {
    $("#Graph02 .wages input").focus(function () {
        $(this).val(0);
        macroModels.prototype.updatePart2Table();
        demo.clearAll();
    }).focusout(function () {
        macroModels.prototype.updatePart2Table();
        demo.clearAll();
    });
    $("#Graph01 .consumption input").focus(function () {
        $(this).val(0);
        macroModels.prototype.updatePart1Table();
        $("#jsxGraph_03 svg line[stroke='#008000'],#jsxGraph_03 svg line[stroke='red']").remove();
        demo.part1UpdateWagesGraph();
    }).focusout(function () {
        macroModels.prototype.updatePart1Table();
        $("#jsxGraph_03 svg line[stroke='#008000'],#jsxGraph_03 svg line[stroke='red']").remove();
        demo.part1UpdateWagesGraph();

     });
}
var part2Wages = [], part2Consumption = [];
macroModels.prototype.updatePart2Table = function () {

    $("#Graph02 #table .wealth").each(function (e) {

        $(this).siblings(".consumption").text((Number(Number($("#Graph02 .wages input").eq(0).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 1))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(1).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 2))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(2).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 3))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(3).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 4))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(4).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 5))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(5).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 6))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(6).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 7))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(7).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 8))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(8).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 9))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(9).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 10))) +
                Number($("#Graph02 #table tr").find(".wages input").eq(10).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 11))) +
                Number($("#Graph02 .wages input").eq(11).val()) * (Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), (12 - 12)))) / Number((Math.pow(Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5), 12) - 1) / (Math.pow((1 + Number($("#Graph02 .intro .rholder .rhinput")[0].value) / 100), 5) - 1))).toFixed(0))

        if (e > 0) {
            $("#Graph02 .wealth").eq(e).text(Math.round((Number($("#Graph02 .wealth").eq(e-1).text())*Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),5)+((Number($("#Graph02 .wages input").eq(e - 1).val())-Number($("#Graph02 .consumption").eq(e - 1).text()))*((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),2) +Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),3)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),4)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),5)))).toFixed(0)));
            
            
            $("#Graph02 .interest").eq(e).text(Math.round((Number($("#Graph02 .wealth").eq(e).text())*Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),5) -(Number($("#Graph02 .wealth").eq(e).text()))+( (Number($("#Graph02 .wages input").eq(e - 1).val())- Number($("#Graph02 .consumption").eq(e - 1).text()))*((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),2) +Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),3)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),4)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),5)-5))).toFixed(0)));
            
        }
        else{
             $("#Graph02 .interest").eq(e).text(Math.round((((Number($("#Graph02 .wages input").eq(e).val())-Number($("#Graph02 .consumption").eq(e).text())))*((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),2) +Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),3)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),4)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),5)-5)).toFixed(0)));
        }
        part2Wages[e] = Number($("#Graph02 .wages input").eq(e).val());
        part2Consumption[e] = Number($("#Graph02 .consumption").eq(e).text());

    });
    
    $("#Graph02 #table .wealthEnd").text(Math.round((Number($("#Graph02 .wealth").eq($("#Graph02 #table .wealth").length - 1).text())*Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),5)+((Number($("#Graph02 .wages input").eq($("#Graph02 #table .wealth").length - 1).val())-Number($("#Graph02 .consumption").eq($("#Graph02 #table .wealth").length - 1).text()))*((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),2) +Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),3)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),4)+Math.pow((1+Number($("#Graph02 .intro .rholder .rhinput")[0].value)/100),5)))).toFixed(0)));
};


var part1Wages = [], part1Consumption = [], lineGraphX = [], lineGraphY = [];
macroModels.prototype.updatePart1Table = function () {
    $("#Graph01 .wealth").each(function (e) {
        
        if (e > 0) {
            $("#Graph01 .wealth").eq(e).text(Math.round((Number($("#Graph01 .wealth").eq(e-1).text())*Math.pow((1.03),5)+((Number($("#Graph01 .wages").eq(e-1).text())-Number($("#Graph01 .consumption input").eq(e-1).val()))*5.46841)).toFixed(0)));
            
            $("#Graph01 .interest").eq(e).text(Math.round((Number($("#Graph01 .wealth").eq(e).text())*Math.pow((1.03),5)-Number($("#Graph01 .wealth").eq(e).text())+( ( Number($("#Graph01 .wages").eq(e-1).text())-Number($("#Graph01 .consumption input").eq(e-1).val()))*0.46841)).toFixed(0)));
          }
          else{

              $("#Graph01 .interest").eq(e).text(Math.round(((( Number($("#Graph01 .wages").eq(e).text()) -Number($("#Graph01 .consumption input").eq(e).val())))*0.46841).toFixed(0)));
          }
        part1Wages[e] = Number($("#Graph01 .wages").eq(e).text());
        part1Consumption[e] = Number($("#Graph01 .consumption input").eq(e).val());
    });
    var count = 0;
    for (var i = 0; i < $("#Graph01 .age").length; i++) {
        //console.log("i"+i);
        for (var j = 0; j <= 4; j++) {
            //console.log(Number($("#Graph01 .wages").eq(i).text()))
            lineGraphX[count + j] = count + j;
            lineGraphY[count + j] = yValConvert(Number($("#Graph01 .wages").eq(i).text()));
        }
        count = count + 5;
    }
 $("#Graph01 .part1Table .wealthEnd").text(Math.round((Number($("#Graph01 .wealth").eq($("#Graph01 .part1Table .wealth").length - 1).text())*Math.pow((1.03),5)+((Number($("#Graph01 .wages").eq($("#Graph01 .part1Table .wealth").length - 1).text())-Number($("#Graph01 .consumption input").eq($("#Graph01 .part1Table .wealth").length - 1).val()))*5.46841)).toFixed(0)));

};
$(function () {
    Model = new macroModels();
    Model.LoadXML();
    demo.Init();
});

var Model;