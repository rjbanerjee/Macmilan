/**
 * Loads the XML File from the Defined Path. 
 * @param   {String} filename Relative Path of the XML File.
 * @returns {String} Return the XML as a String.
 */
function loadXMLDoc(filename) {
	if (window.XMLHttpRequest) {
		xhttp = new XMLHttpRequest();
	} else {
		xhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xhttp.open("GET", filename, false);
	xhttp.async = false;
	xhttp.send(null);
	return xhttp.response;
}

/**
 * The Function Parse the XML String to the XML Object .
 * @param   {String} string XML in String Format.
 * @returns {Object} Return the XML Object.
 */
function parseXMLString(string){
	if (window.DOMParser) {
		parser = new DOMParser();
		return xmlDoc = parser.parseFromString(string, "text/xml");
	} else // Internet Explorer
	{
		xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
		xmlDoc.async = false;
		return xmlDoc.loadXML(string);
	}
}
