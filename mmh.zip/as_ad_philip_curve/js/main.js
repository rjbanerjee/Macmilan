/**
 * Main _Contructor Function of this Application.
 */
function macroModels() {
    this._xmlFileName = "Activity.xml";
    this._xmlFilePath = "./xml/";
    this._xmlObject = null;
    this._activityTitle = null;
    this._activityYear = 2001;
}

/**
 * Function Loads the Macromodel Activity XML from the configured parameters in _Constructor.
 * The Function Store the XML Object in the Defined Variable in _Constructor.
 */
macroModels.prototype.LoadXML = function () {
    //Loading XML File.
    this._xmlObject = loadXMLDoc(this._xmlFilePath + this._xmlFileName);
    //Parsing XML String.
    this._xmlObject = parseXMLString(this._xmlObject);
    //The Main DOM is been added in Object.
    this._xmlObject = this._xmlObject.getElementsByTagName("activity")[0];
    this.GenerateHTML();
    this.controlTab();
}

/**
 * [[Description]]
 */


macroModels.prototype.GenerateHTML = function () {
    //Title Name
    this._activityTitle = this._xmlObject.getElementsByTagName("heading")[0].childNodes[0].nodeValue;
    $("title").html(this._activityTitle);
    $(".modelTitle a").html(this._activityTitle);
    $(".questionHolder p").html(this._xmlObject.getElementsByTagName("question")[0].childNodes[0].nodeValue);
    var _activityTabsCount = this._xmlObject.getElementsByTagName("section").length;
    for (i = 0; i < _activityTabsCount; i++) {
        $(".nav li:eq(" + i + ") a").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "content") {
            $(".tab-pane :eq(" + i + ") p").html(this._xmlObject.getElementsByTagName("section")[0].childNodes[1].textContent);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContent") {
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[1].childNodes[1].textContent);
            var xmlObj = this._xmlObject;
            var quesparameter = '';
            var that = this;
            $(xmlObj).find("rangeOptions").find("options").each(function (e) {
                quesparameter += '<div class="rangeShell"><div class="rholder" id = "title' + (e + 1) + '" aria-label = "' + $(this).find("title").text() + '"><h5>' + $(this).find("title").text() + " <span class='rangeYear'>" + that._activityYear + '</span><span class = "hiddenText">TextBox</span></h5></div><div class="rholder"><span class="minRange">' + $(this).find("minLimit").text() + '</span><input type="text" class="modelInput" value="0.00")/><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
            });
            $("." + $(xmlObj).find("rangeOptions").attr("id")).html(quesparameter);
        }
    }
    $(".controlSection").hide();

    setTimeout(function () {
        $("svg").before("<span class = 'hiddenText1'>This is a AS-AD Model and the Philips Curve Graph</span>");
        $("svg").attr("focusable", "false");
        $("li > a").blur();
        $(".tab-pane").attr("role", "alert");
    }, 200);
    
    


    this.Event();
};
macroModels.prototype.controlTab = function () {
    $("ul > li.active").children().attr("tabindex", "-1");

    $("ul > li").on("click", function () {

        // Can add another method and properties
        if ($(this).index() !== 0) {
            $(".controlSection").show();
        } else {
            $(".controlSection").hide();
        }
        setTimeout(function () {
            if ($("ul > li.active").children().attr("aria-expanded") == "true") {
                //setTimeout(function(){alert(0);$("#jxgbox > svg").attr("tabindex","0").focus()},250)
                $("ul > li").children().removeAttr("tabindex");
                $("ul > li.active").children().attr("tabindex", "-1");
                if ($("ul > li.active").children().attr("href") == "Graph01") {
                    $(".controlSection").attr("role", "alert");
                }
            }

        }, 250);
        setTimeout(function () {
            $(".tab-pane").attr("role", "alert");
        }, 500);
        setTimeout(function () {
            $(".controlSection").attr("tabindex", "0").focus();
        }, 5000);


    });
};

/**
 * The Application On Ready Initialise. 
 * Create the Main Object Class.
 */

macroModels.prototype.Event = function () {
    var parameter = false;
    //question parameter click && parameter back click
    $(".param,.introback").off("click").on("click", function () {
        parameter = !parameter;
        // Can add another method and properties
        if (parameter) {
            $(".introHolder").removeClass('elementShow').addClass('elementHide');
            $(".rangeholder").removeClass('elementHide').addClass('elementShow');
            $(".introback").attr("tabIndex", "0").focus();
            $(".rangeholder").removeAttr("aria-hidden", "false");
            setTimeout(function () {
                $(".rangeholder").attr("role", "alert");
            }, 250);
        }
        else {
            $(".rangeholder").removeClass('elementShow').addClass('elementHide');
            $(".introHolder").removeClass('elementHide').addClass('elementShow');
            $(".param").attr("tabIndex", "0").focus();
            setTimeout(function () {
                $(".introHolder").attr("role", "alert");
            }, 250);
        }
    });
    this.createTable();
}
 var yearCalculation = [];
macroModels.prototype.createTable = function () {
    var that = this;
    var table = '';
    var header = ['Expected Inflation (%)', 'Supply Shock (%)', 'Nominal GDP (%)', 'Inflation (%)', 'Unemployment (%)', 'Output ($ bil)'];
    var startYearData = ["8.00", "0.00", "8.00", "8.00", "5.00", "5000"];
            table = $('<table></table>');
   
    for (var i = 0; i <= 6; i++) {
        var row = $('<tr></tr>');
        for (var j = 0; j < 13; j++) {
            var column;

            if (i === 0) {
                if (j !== 0) {
                    column = $('<th class="elementHide"></th>').text(that._activityYear - (3 - j));
                    yearCalculation[j] = that._activityYear - (3 - j);
                }
                else {
                    column = $('<th  class="heading"></th>').text("");
                    yearCalculation[j] = 0;
                }
            }
            else {
                if (j === 0) {
                    column = $('<td class="heading"></td>').text(header[i - 1]);
                }
                else {
                    column = $('<td class="' + header[i - 1].replace("(%)", "").replace("($ bil)", "").replace(/\s/g, '').toLowerCase() + ' elementHide"></td>').text(startYearData[(i - 1)]);
                }
            }
            table.append(row);
            row.append(column);
        }
    }
    $('.tableView').html(table);
    this.showTable($.inArray(that._activityYear, yearCalculation));
};

macroModels.prototype.showTable = function (ind) {
    $('.tableView tr th,.tableView tr td').addClass("elementHide");
    $(".heading").removeClass("elementHide");
    for (var i = 0; i < $('.tableView tr').length; i++) {
        for (var j = (ind - 2); j <= ind; j++) {
            $('.tableView tr').eq(i).children().eq(j).removeClass("elementHide");
            if (i > 3) {
                $('.tableView tr').eq(i).children().eq(ind).addClass("elementHide");
            }
        }
    }
    this.bindEvent(ind);
};
macroModels.prototype.bindEvent = function (ind) {
   // console.log(ind)
    var that = this;
    $(".modelInput").off("focusin").on("focusin",function () {
        $(this).attr("aria-label",$(this).parent().siblings().text());
        that.inputFocusEventBind($(this), ind);
    });
    $(".modelInput").off("focusout").on("focusout",function () {
        that.inputFocusEventBind($(this), ind);
      });
    $(".modelInput").eq(1).off("keypress").on("keypress",function (e) {
        if (e.keyCode === 13)
        {
            that.inputFocusEventBind($(this), ind);
            that._activityYear++;
            $(".rangeYear").html(that._activityYear);
            $(".modelInput").val((Number(0)).toFixed(2))
            that.showTable($.inArray(that._activityYear, yearCalculation));
             demo.curveUpdation();
        }
    });
    $(".supplyshock").eq(ind - 1).text((Number($(".modelInput").eq(0).val())).toFixed(2));
    $(".nominalgdp").eq(ind - 1).text((Number($(".modelInput").eq(1).val())).toFixed(2));
    that.updateTable();
};
macroModels.prototype.inputFocusEventBind = function (obj, ind) {
 //   console.log(ind - 1);
  //  console.log(obj.val()  <  Number(obj.siblings(".minRange").text()));
  //  console.log(obj.val() > Number(obj.siblings(".maxRange").text()))
    if (obj.val() < Number(obj.siblings(".minRange").text())) {
        //console.log(obj.siblings(".minRange").text())
        obj.val((Number(obj.siblings(".minRange").text())).toFixed(2));
    }
    else if (obj.val() > Number(obj.siblings(".maxRange").text())) {
        obj.val((Number(obj.siblings(".maxRange").text())).toFixed(2));
    }
    else {
        obj.val((Number(obj.val())).toFixed(2));
    }
    $(".supplyshock").eq(ind - 1).text((Number($(".modelInput").eq(0).val())).toFixed(2));
    $(".nominalgdp").eq(ind - 1).text((Number($(".modelInput").eq(1).val())).toFixed(2));
    this.updateTable();
}
macroModels.prototype.updateTable = function () {

    for (var i = 1; i < $('.tableView tr').length; i++) {
        $(".expectedinflation").eq(i).text($(".expectedinflation").eq(i - 1).text());
        
        $(".unemployment").eq(i).text((Number($(".unemployment").eq(i - 1).text())-Number($(".output").eq(i - 1).text())*(Number($(".nominalgdp").eq(i).text())-Number($(".expectedinflation").eq(i).text()))/15625+Number($(".supplyshock").eq(i).text())*0.35).toFixed(2));
         
        $(".inflation").eq(i).text((Number($(".expectedinflation").eq(i).text())+(Number( $(".output").eq(i-1).text())*(1+Number($(".nominalgdp").eq(i).text())/100)/(1+Number($(".expectedinflation").eq(i).text())/100)-5000)*0.13/46.296296296296+Number($(".supplyshock").eq(i).text())).toFixed(2));
        
         $(".output").eq(i).text((Number($(".output").eq(i - 1).text())*(1+Number($(".nominalgdp").eq(i).text())/100)/(1+Number($(".inflation").eq(i).text())/100)).toFixed(0));
    }
    
   
};


macroModels.prototype.getType = function (input) {
    var m = (/[\d]+(\.[\d]+)?/).exec(input);
    if (m) {
        // Check if there is a decimal place
        if (m[1]) {
            return 'float';
        }
        else {
            return 'int';
        }
    }
    return 'string';
};
$(function () {
    Model = new macroModels();
    Model.LoadXML();
    demo.Init();
});

var Model;