var demo = {};
var asadboard, philipcurveBoard, inflationBoard, unemploymentBoard;
var inflationCurve = {"val1": [0, 1], "val2": [8, 8]};
var unemploymentCurve = {"val1": [0, 1], "val2": [5, 5]};
//X Axis Value Conversion
var xASADValConvert = function (x) {
    var min = 4000;
    var max = 6000;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 4;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//Y Axis Value Conversion
var yASADValConvert = function (y) {
    var min = 0;
    var max = 25;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 25;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};

//X Axis Value Conversion
var xPhillipValConvert = function (x) {
    var min = 2;
    var max = 8;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 6;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//Y Axis Value Conversion
var yPhillipValConvert = function (y) {
    var min = -20;
    var max = 20;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 40;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};

var philipcurvePreviousYearlinequation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
    // console.log(-0.5*(num-Number($(".tableView tr").eq(5).find(".unemployment").eq(yearCalc - 2).text()))+Number($(".tableView tr").eq(4).find(".inflation").eq(yearCalc - 2).text()))
    return Number((-0.5 * (num - Number($(".tableView tr").eq(5).find(".unemployment").eq(yearCalc - 2).text())) + Number($(".tableView tr").eq(4).find(".inflation").eq(yearCalc - 2).text())).toFixed(2));


};
var philipcurveCurrentYearlinequation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);

    return Number((-0.5 * (num - Number($(".tableView tr").eq(5).find(".unemployment").eq(yearCalc - 1).text())) + Number($(".tableView tr").eq(4).find(".inflation").eq(yearCalc - 2).text())).toFixed(2));
};

var asCurveFirstYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);

    return Number((Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 3).text()) + (num * (1 + Number($(".tableView tr").eq(3).find(".nominalgdp").eq(yearCalc - 3).text()) / 100) / (1 + Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 3).text()) / 100) - 5000) * 0.13 / 46.296296296296 + Number($(".tableView tr").eq(2).find(".supplyshock").eq(yearCalc - 3).text())).toFixed(2));
};

var asCurveMiddleYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);

    return Number((Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 2).text()) + (num * (1 + Number($(".tableView tr").eq(3).find(".nominalgdp").eq(yearCalc - 2).text()) / 100) / (1 + Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 2).text()) / 100) - 5000) * 0.13 / 46.296296296296 + Number($(".tableView tr").eq(2).find(".supplyshock").eq(yearCalc - 2).text())).toFixed(2));
};

var asCurveCurrentYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);

    return Number((Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 1).text()) + (num * (1 + Number($(".tableView tr").eq(3).find(".nominalgdp").eq(yearCalc - 1).text()) / 100) / (1 + Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 1).text()) / 100) - 5000) * 0.13 / 46.296296296296 + Number($(".tableView tr").eq(2).find(".supplyshock").eq(yearCalc - 1).text())).toFixed(2));
};

var adCurveFirstYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
    var calculation = (Number($(".rangeYear").eq(0).text()) - 2 === 1999) ? 5000 : Number($(".tableView tr").eq(6).find(".output").eq(yearCalc - 3).text());
    return Math.round(Number((calculation * (1 + Number($(".tableView tr").eq(3).find(".nominalgdp").eq(yearCalc - 3).text()) / 100) - 470 / 0.91 * (num - Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 3).text()))).toFixed(2)));
};

var adCurveMiddleYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);

    return Math.round(Number((Number($(".tableView tr").eq(6).find(".output").eq(yearCalc - 3).text()) * (1 + Number($(".tableView tr").eq(3).find(".nominalgdp").eq(yearCalc - 2).text()) / 100) - 470 / 0.91 * (num - Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 2).text()))).toFixed(2)));
};

var adCurveCurrentYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);

    return Math.round(Number((Number($(".tableView tr").eq(6).find(".output").eq(yearCalc - 2).text())*(1+Number($(".tableView tr").eq(3).find(".nominalgdp").eq(yearCalc - 1).text())/100)-470/0.91*(num-Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 1).text()))).toFixed(2)));
};


demo.Init = function () {
    /*AS-AD Borad*/
    asadboard = JXG.JSXGraph.initBoard('asadBox', {
        axis: false,
        boundingbox: [0, 25, 4, -1.5],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
//    asadboard.create('text', [-0.5, 25, "25.00"]);
//    asadboard.create('text', [-0.2, 12, "p"]);
//    asadboard.create('text', [-0.2, 1, "0"]);
    asadboard.create('text', [0, -0.05, "4000"]);
    asadboard.create('text', [1.7, -0.05, "Y($ billions)"]);
    asadboard.create('text', [3.6, -0.05, "6000"]);
    asadboard.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    asadboard.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    asadboard.create('line', [[xASADValConvert(4000), yASADValConvert(asCurveFirstYearEquation(4000))], [xASADValConvert(6000), yASADValConvert(asCurveFirstYearEquation(6000))]], {
        strokeWidth: 1.5,
        strokeColor: '#95F2D8',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
         //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AS'"+(Number($(".rangeYear").eq(0).text()) - 2).toString().substr(2,2);
        },
        withLabel: true,
        label: {offset: [10, 25],color: '#95F2D8',cssClass:'myBold'
        }
    });
     asadboard.create('line', [[xASADValConvert(adCurveFirstYearEquation(0)), yASADValConvert(0)], [xASADValConvert(adCurveFirstYearEquation(25)), yASADValConvert(25)]], {
        strokeWidth: 1.5,
        strokeColor: '#D90000',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
         //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AD'"+(Number($(".rangeYear").eq(0).text()) - 2).toString().substr(2,2);
        },
        withLabel: true,
        label: {offset: [10, 0],color: '#D90000', cssClass:'myBold'
        }
    });
    
   asadboard.create('line', [[xASADValConvert(4000), yASADValConvert(asCurveMiddleYearEquation(4000))], [xASADValConvert(6000), yASADValConvert(asCurveMiddleYearEquation(6000))]], {
        strokeWidth: 1.5,
        strokeColor: '#DD3232',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
         //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AS'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2);
        },
        withLabel: true,
        label: {offset: [10, 0],color: '#DD3232',cssClass:'myBold'
        }
    });

asadboard.create('line', [[xASADValConvert(adCurveMiddleYearEquation(0)), yASADValConvert(0)], [xASADValConvert(adCurveMiddleYearEquation(25)), yASADValConvert(25)]], {
        strokeWidth: 1.5,
        strokeColor: '#4B738F',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
         //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AD'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2);
        },
        withLabel: true,
        label: {offset: [10, 0],color: '#4B738F',cssClass:'myBold'
        }
    });
    
    asadboard.create('line', [[xASADValConvert(4000), yASADValConvert(asCurveCurrentYearEquation(4000))], [xASADValConvert(6000), yASADValConvert(asCurveCurrentYearEquation(6000))]], {
        strokeWidth: 1.5,
        strokeColor: '#243C90',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
         //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AS'"+(Number($(".rangeYear").eq(0).text())).toString().substr(2,2);
        },
        withLabel: true,
        label: {offset: [10, 0],color: '#243C90',cssClass:'myBold'
        }
    });

asadboard.create('line', [[xASADValConvert(adCurveCurrentYearEquation(0)), yASADValConvert(0)], [xASADValConvert(adCurveCurrentYearEquation(25)), yASADValConvert(25)]], {
        strokeWidth: 1.5,
        strokeColor: '#B34715',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
         //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AD'"+(Number($(".rangeYear").eq(0).text())).toString().substr(2,2);
        },
        withLabel: true,
        label: {offset: [10, 0],color: '#B34715',cssClass:'myBold'
        }
    });
    /*Philip Curve Borad*/

    philipcurveBoard = JXG.JSXGraph.initBoard('philipBox', {
        axis: false,
        boundingbox: [0, 40, 6, -2.7],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
//    philipcurveBoard.create('text', [-0.7, 40, "20.00"]);
//    philipcurveBoard.create('text', [-0.7, 25, "Infl"]);
//    philipcurveBoard.create('text', [-0.8, 2, "-20.00"]);
    philipcurveBoard.create('text', [0, -0.5, "2"]);
    philipcurveBoard.create('text', [3, -0.5, "U"]);
    philipcurveBoard.create('text', [5.75, -0.5, "8"]);
    philipcurveBoard.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    philipcurveBoard.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    philipcurveBoard.create('line', [[xPhillipValConvert(2), yPhillipValConvert(8)], [xPhillipValConvert(8), yPhillipValConvert(8)]], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "Einfl",
        withLabel: true,
        label: {offset: [270, -5],cssClass:'philipBold'}
    });
    philipcurveBoard.create('line', [[xPhillipValConvert(5), yPhillipValConvert(-20)], [xPhillipValConvert(5), yPhillipValConvert(20)]], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "Unat",
        withLabel: true,
        label: {offset: [5, 200],cssClass:'philipBold'}
    });
    philipcurveBoard.create('line', [[xPhillipValConvert(2), yPhillipValConvert(philipcurvePreviousYearlinequation(2))], [xPhillipValConvert(8), yPhillipValConvert(philipcurvePreviousYearlinequation(8))]], {
        strokeWidth: 2,
        strokeColor: '#D90000',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
            return Number($(".rangeYear").eq(0).text()) - 1;
        },
        withLabel: true,
        label: {offset: [270, 10], color: "#D90000"}
    });

    philipcurveBoard.create('line', [[xPhillipValConvert(2), yPhillipValConvert(philipcurveCurrentYearlinequation(2))], [xPhillipValConvert(8), yPhillipValConvert(philipcurveCurrentYearlinequation(8))]], {
        strokeWidth: 2,
        strokeColor: 'blue',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
            return Number($(".rangeYear").eq(0).text());
        },
        withLabel: true,
        label: {offset: [10, 15], color: "blue"}
    });


    /*Inflation Borad*/

    inflationBoard = JXG.JSXGraph.initBoard('infaltionBox', {
        axis: false,
        boundingbox: [-1.3, 25, 12, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    inflationBoard.create('text', [-1.3, 25, "20.00"]);
    inflationBoard.create('text', [-0.7, 12, "%"]);
    inflationBoard.create('text', [-1.2, 2, "-5.00"]);
//    inflationBoard.create('text', [0, -0.2, "1998"]);
//    inflationBoard.create('text', [6, -0.2, "Year"]);
//    inflationBoard.create('text', [10.9, -0.2, "2010"]);
    


    inflationBoard.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    inflationBoard.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    inflationBoard.create('curve', [inflationCurve.val1, inflationCurve.val2], {strokeColor: '#D90000', name: "", highlight: false, strokeWidth: 1.5, fixed: true, withLabel: true, label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-180, 0] // (in pixels)
        }});

    /*Unemployment Borad*/

    unemploymentBoard = JXG.JSXGraph.initBoard('unemploymentBox', {
        axis: false,
        boundingbox: [-1.3, 10, 12, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });

    unemploymentBoard.create('text', [-1.3, 10, "10.00"]);
    unemploymentBoard.create('text', [-0.7, 5, "%"]);
    unemploymentBoard.create('text', [-1.05, 0.7, "0.00"]);
//    unemploymentBoard.create('text', [0, -0.2, "1998"]);
//    unemploymentBoard.create('text', [6, -0.2, "Year"]);
//    unemploymentBoard.create('text', [10.9, -0.2, "2010"]);


    unemploymentBoard.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    unemploymentBoard.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    unemploymentBoard.create('curve', [unemploymentCurve.val1, unemploymentCurve.val2], {strokeColor: '#606060', name: "", highlight: false, strokeWidth: 1.5, fixed: true, withLabel: true, label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-180, 0] // (in pixels)
        }});
    this.curveUpdation();
};
demo.curveUpdation = function () {
    var totalNumberYears = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation)
    for (var i = 0; i < totalNumberYears - 1; i++) {
        inflationCurve.val1[i] = i;
        unemploymentCurve.val1[i] = i;
        inflationCurve.val2[i] = Number($(".inflation").eq(i).text());
        unemploymentCurve.val2[i] = Number($(".unemployment").eq(i).text());
    }
    this.graphManupulation();
}
demo.graphManupulation = function () {
    asadboard.fullUpdate();
    philipcurveBoard.fullUpdate();
    inflationBoard.fullUpdate();
    unemploymentBoard.fullUpdate();
};
  