
var demo = {};
var board;
var spending = 90, interestRate = 2.4,cost = 7, minutes = 22;
var LineCalRed = function(x){
      return x*spending/2*interestRate/100;
      
};
var LineCalblue = function(x){
          return 365/x*cost*minutes/60;
};
var LineCaltotal = function(x){
          return x*spending/2*interestRate/100+365/x*cost*minutes/60;
};
demo.Init = function () {

    board = JXG.JSXGraph.initBoard('jxgbox', {
        boundingbox: [-12, 100, 101, -10],
        axis: false,
        grid: false,
        withLabel: false,
        showCopyright: false, 
        showNavigation: false
    });

    var xaxis = board.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: false,
        name: 'X',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#606060',
        strokeWidth: 2,
        label: {
            position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, 10]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0}
    });


    var yaxis = board.create('axis', [[0, 0], [0, 1]],
            {name: 'y',
                withLabel: false,
                straightFirst: false,
                straightLast: true,
                firstArrow: false,
                lastArrow: false,
                 strokeColor: '#606060',
             strokeWidth: 2,
                label: {
                    position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [10, 10]   // (in pixels)
                },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: '#008000',
                    majorHeight: 0}
            });
 var redLineInt = board.create('functiongraph', [function (x) {
          return LineCalRed(x);
        }, 0,100], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        strokeColor: '#A42929',
        highlight: false,
         withLabel: true,
        name: "INT",
         label: { 
         offset: [-15, 20],
         cssClass: 'redIntLine'},
        fixed: true});
    var blueLineBank = board.create('functiongraph', [function (x) {
          return LineCalblue(x);
        }, 0,100], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        strokeColor: 'blue',
        highlight: false,
         withLabel: true,
        name: "BNK",
         label: { 
         offset: [250, -120],
         anchorX: 'bottom',
         anchorY: 'bottom',
         cssClass: 'blueBankLine'},
        fixed: true});
    
        var greenLineTotal = board.create('functiongraph', [function (x) {
          return LineCaltotal(x);
        }, 0,100], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        strokeColor: '#008000',
        highlight: false,
         withLabel: true,
        name: "Total",
         label: { 
         offset: [100, 10],
         position : 'middle',
         cssClass: 'totalLine'},
         fixed: true});
    var text1 = board.create('text', [-.2, -.2, "1"]);
    var text2 = board.create('text', [-12, 100, "100.00"]);
    var text3 = board.create('text', [40, -.2, "days between visits"], {cssClass:'italics'});
    var text4 = board.create('text', [-9, 3.8, "0.00"]);
    var text5 = board.create('text', [95, -.2, "100.00"]);
    var text6 = board.create('text', [-9, 50, "cost"], {cssClass:'italics'});

this.sliderSelection();
};
demo.sliderSelection = function(){
    $("input[id^='ex']").each(function (){
      $(this).initiateSlider();
    });
   };

$.fn.initiateSlider = function () {
     var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
            var vElmValue = (parseInt(value) === value) ? value : value.toFixed(2);
            oThisElm.parent().parent().find(".rhinput").val(vElmValue);
            demo.fieldUpdation();
            return 'Current value: ' + value;
            
        }
    });
}

demo.fieldUpdation=function(){
    $("svg").attr("focusable","false");
   $(".block01 .rholder .rhinput")[6].value=Number($(".block01 .rholder .rhinput")[6].value).toFixed(2);
    //baseline input boxes calculation
     $("#baseline_1").val(Math.round(Math.pow(2*Number($(".block01 .rholder .rhinput")[4].value)*365*Number($(".block01 .rholder .rhinput")[1].value)*Number($(".block01 .rholder .rhinput")[2].value)/(60*Number($(".block01 .rholder .rhinput")[6].value)/100),0.5)));
      $("#baseline_0").val((365/(Number($(".block01 .rholder .rhinput")[4].value)*365/Math.pow(2*Number($(".block01 .rholder .rhinput")[4].value)*365*Number($(".block01 .rholder .rhinput")[1].value)*Number($(".block01 .rholder .rhinput")[2].value)/(60*Number($(".block01 .rholder .rhinput")[6].value)/100),0.5))).toFixed(2));
    $("#baseline_2").val((Number($("#baseline_1").val())/2).toFixed(2));
    $("#baseline_3").val((Number($("#baseline_2").val())*(Number($(".block01 .rholder .rhinput")[6].value)/100)).toFixed(2));
    $("#baseline_4").val((Number($(".block01 .rholder .rhinput")[4].value)*365/Math.pow((2*Number($(".block01 .rholder .rhinput")[4].value)*365*Number($(".block01 .rholder .rhinput")[1].value)*Number($(".block01 .rholder .rhinput")[2].value)/(60*Number($(".block01 .rholder .rhinput")[6].value)/100)),0.5)).toFixed(2));
  
    
    $("#baseline_5").val((Number($(".block01 .rholder .rhinput")[4].value)*365/Math.pow((2*Number($(".block01 .rholder .rhinput")[4].value)*365*Number($(".block01 .rholder .rhinput")[1].value)*Number($(".block01 .rholder .rhinput")[2].value)/(60*Number($(".block01 .rholder .rhinput")[6].value)/100)),0.5)*(Number($(".block01 .rholder .rhinput")[1].value)*Number($(".block01 .rholder .rhinput")[2].value)/60)).toFixed(2));
   
    
    $("#baseline_6").val((Number($("#baseline_3").val())+Number($("#baseline_5").val())).toFixed(2));
    
  
 
   demo.graphManupulation();
};
demo.graphManupulation = function () {
   spending = Number($(".block01 .rholder .rhinput")[4].value), interestRate =Number($(".block01 .rholder .rhinput")[6].value),cost = Number($(".block01 .rholder .rhinput")[1].value), minutes = Number($(".block01 .rholder .rhinput")[2].value);
     board.fullUpdate();
};
    