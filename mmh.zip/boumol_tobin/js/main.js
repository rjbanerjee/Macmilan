/**
 * Main _Contructor Function of this Application.
 */
function macroModels() {
    this._xmlFileName = "Activity.xml";
    this._xmlFilePath = "./xml/";
    this._xmlObject = null;
    this._activityTitle = null;
    this._activitySliderCount = 0;
}

/**
 * Function Loads the Macromodel Activity XML from the configured parameters in _Constructor.
 * The Function Store the XML Object in the Defined Variable in _Constructor.
 */
macroModels.prototype.LoadXML = function () {
    //Loading XML File.
    this._xmlObject = loadXMLDoc(this._xmlFilePath + this._xmlFileName);
    //Parsing XML String.
    this._xmlObject = parseXMLString(this._xmlObject);
    //The Main DOM is been added in Object.
    this._xmlObject = this._xmlObject.getElementsByTagName("activity")[0];
    this.GenerateHTML();
    this.controlTab();
    this.numericChecker();
    //this.roundOff();

}


window.addEventListener("orientationchange", function() {
  $("input").blur(); 
}, false);
/**
 * [[Description]]
 */


macroModels.prototype.GenerateHTML = function () {
    // stri  
    //Title Name
    this._activityTitle = this._xmlObject.getElementsByTagName("heading")[0].childNodes[0].nodeValue;
    $("title").html(this._activityTitle);
    $(".modelTitle a").html(this._activityTitle);
    $(".questionHolder p").html(this._xmlObject.getElementsByTagName("question")[0].childNodes[0].nodeValue);
    var _activityTabs = this._xmlObject.getElementsByTagName("section");
    var _activityTabsCount = this._xmlObject.getElementsByTagName("section").length;
    for (i = 0; i < _activityTabsCount; i++) {
        $(".nav li:eq(" + i + ") a").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "content") {
            //$(".tab-pane :eq(" + i + ") h3").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

            $(".tab-pane :eq(" + i + ") p").html(this._xmlObject.getElementsByTagName("section")[0].childNodes[1].textContent);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "mcqContent") {
            var mcqDom = '';
            var xmlObj = this._xmlObject.getElementsByTagName("section")[1];
            $(xmlObj).find("questionSet").each(function (e) {
                if ($(this).attr("type") !== "baseline") {
                    mcqDom += '<section class="questionSet"><div class="sliderquestion">' + $(this).find("question").text() + '</div><div><table>';
                    $(this).find("options").find("option").each(function (e) {
                        var userInputAllowed = ($(this).attr("disabled") === "true") ? "disabled" : "";
                        mcqDom += '<tr><td><label for = "' + $(this).text() + '">' + $(this).text() + '<span class = "hiddenText">input box type a text</span></label></td><td><input id="' + $(this).text() + '" maxlength = "5" type="text" ' + userInputAllowed + ' value=""/></td></tr>';
                    });
                    mcqDom += '</table></div><div class="sliderfooter">' + $(this).find("footer").text() + '</div></section>';
                }
                else {
                    mcqDom += '<section class="questionSet"><div><table><thead><tr><th></th><th>Your Baseline</th><th>Alternative</th></tr><thead>';
                    $(this).find("options").find("option").each(function (e) {
                        var yourbaseline = ($(this).attr("yourbaseline") === "true") ? "disabled" : "";
                        var alternative = ($(this).attr("alternative") === "true") ? "disabled" : "";
                        mcqDom += '<tr><td><label>' + $(this).text() + '</label></td><td><input maxlength = "5" type="text" ' + yourbaseline + ' value=""/></td><td><input maxlength = "5" type="text" ' + alternative + ' value=""/></td></tr>';
                    });
                    mcqDom += '</table></div><div class="sliderfooter">' + $(this).find("footer").text() + '</div></section>';
                }
            });
            $("." + $(xmlObj).attr("id")).html(mcqDom);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContent") {
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[2].childNodes[1].textContent);
            var xmlObj = this._xmlObject.getElementsByTagName("section")[2];
            var sliderObjCounter = 0;
            var exogenousrangeparameter = '';
            var exogenousparameter = '';
            $(xmlObj).find("exogenousrange").find("options").each(function (e) {
                exogenousrangeparameter += '<div class="rangeShell" id = "range_' + (e + 1) + '"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">slider</span></h5></div><div class="rholder"><input type="text" disabled maxlength = "5" title = "' + $(this).find("title").text() + ' slider" value="' + Number($(this).find("value").text()) + '" class="rhinput"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + Number($(this).find("value").text()) + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + $(this).find("value").text() + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("." + $(xmlObj).find("exogenousrange").attr("id")).html(exogenousrangeparameter);

            var baseline = '';

            $(xmlObj).find("exogenousOptions").find("options").each(function (e) {
                baseline += '<tr><td> <label for="' + $(this).find("title").text() + '">' + $(this).find("title").text() + '</label></td><td><input type="text" maxlength = "5" disabled id="baseline_' + e + '" value="' + $(this).find("minLimit").text() + '"></td><td><label>' + $(this).find("minLimit").text() + '</label></td></tr>';

            });
            exogenousparameter += '<span class="descHolderHeader">Baseline</span><table>' + baseline + '</table>';

            $("." + $(xmlObj).find("exogenousOptions").attr("id")).html(exogenousparameter);


        }
    }

    setTimeout(function () {
        $("svg").before("<span class = 'hiddenText1'>The Baumol-Tobin Model of Money Demand graph</span>");
        $("svg").attr("focusable", "false");
        $("li > a").blur();
        /*$(".tab1").attr("role", "alert");
        $(".tab0").children().find("section").eq(0).attr("tabindex", "0").focus();*/
        $(".tab-pane").attr("role","alert");
    }, 200);

    this.Event();
    this.Slider(this._activitySliderCount);

};


/**
 * The Application On Ready Initialise. 
 * Create the Main Object Class.
 */

macroModels.prototype.Event = function () {
    var parameter = false;
    //question parameter click && parameter back click
    $(".param,.introback").off("click").on("click", function () {
        parameter = !parameter;
        // Can add another method and properties
        if (parameter) {
            $(".introHolder").removeClass('elementShow').addClass('elementHide');
            $(".rangeholder").removeClass('elementHide').addClass('elementShow');
        }
        else {
            $(".rangeholder").removeClass('elementShow').addClass('elementHide');
            $(".introHolder").removeClass('elementHide').addClass('elementShow');
        }
    });
    var that = this;
    $(".prev").off("click").on("click", function () {
 setTimeout(function () {
                $(".tab-pane").children().find("section").eq(that._activitySliderCount).attr("tabindex", "0").focus();
            }, 1500);
        if ($(this).css("opacity") !== "0") {

            that._activitySliderCount--;
            macroModels.prototype.Slider(that._activitySliderCount);
           
        }
    });
    $(".next").off("click").on("click", function () {
        $(".sliderCont :input").eq(4).focus();
 setTimeout(function () {
                $(".tab-pane").children().find("section").eq(that._activitySliderCount).find(".sliderquestion").attr("tabindex", "0").focus();
            }, 500);
         setTimeout(function () {
                $(".tab-pane").children().find("section").eq(that._activitySliderCount).find("table").attr("tabindex", "0").focus();
            }, 2000);
        if ($(this).css("opacity") !== "0") {

            that._activitySliderCount++;
            macroModels.prototype.Slider(that._activitySliderCount);
           

        }
    });

};
macroModels.prototype.Slider = function (index) {
    if (index < 1) {
        $(".prev").css({"opacity": 0, "cursor": "default"});
        $(".prev").attr("tabindex", "-1");
        $(".next,.submit").css({"opacity": 1, "cursor": "pointer"});
    }
    else if (index >= ($(".questionSet").length) - 1) {
        $(".next,.submit").css({"opacity": 0, "cursor": "default"});
        $(".prev").css({"opacity": 1, "cursor": "pointer"});
        $(".prev").removeAttr("tabindex", "-1");
        $(".next,.submit").attr("tabindex", "-1");
    }
    else {
        //$(".prev").removeAttr({"tabindex": "-1"});

        $(".next,.submit,.prev").css({"opacity": 1, "cursor": "pointer"}).attr("tabindex", "0");

    }
    $(".questionSet").hide();
    $(".questionSet").eq(index).show();
//    if (!macroModels.prototype.validateInput(index)) {
//        $(".sliderCont .questionSet").eq(index).find("input").val('');
//    }
    macroModels.prototype.sliderValidation(index);
    macroModels.prototype.nanChecker(index);

};
macroModels.prototype.decimalChecker = function (str) {
    var arrValues = str.split('');
    var decimalCount = 0;
    var data = str;
    if (str.length > 0) {
        $(arrValues).each(function (e, v) {
            if (v === ".") {
                decimalCount++;
                if (decimalCount > 1) {
                    data = str.substring(0, (e));
                   
                }
            }

        });
    }
  
               return data; 
};
macroModels.prototype.sliderValidation = function (ind) {
    //$(".sliderCont .questionSet").eq(ind).find(":input:not([disabled])").eq(0).focus();
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        var tab = $(e.target).attr('href');
        $(tab).find(".sliderCont .questionSet").eq(ind).find(":input:not([disabled])").eq(0).focus();
    });
    $(".sliderCont .questionSet").eq(ind).find(":input:not([disabled])").focusout(function () {
        if ((ind !== 2) && (ind !== 4)) {
            if ($(this).val().indexOf(".") !== -1) {
                 var str = macroModels.prototype.decimalChecker($(this).val());
                 var regex = "[^.]*.[^.]*";
                 $(this).val(Math.round(parseFloat(str.match(regex)[0])));
            }
            else {
                 $(this).val(Math.round($(this).val()));
            }
        }
        else {
            if ($(this).val().indexOf(".") !== -1) {

                $(this).val(macroModels.prototype.decimalChecker($(this).val()));
            }
        }
        macroModels.prototype.mcdInputUpdation(ind);
    });
    $(".submit").off("click").on("click", function () {
        macroModels.prototype.mcdInputUpdation(ind);
    });
    macroModels.prototype.lastValidation(ind);
};
macroModels.prototype.mcdInputUpdation = function (slide) {
    if (macroModels.prototype.validateInput(slide)) {
        (($(".sliderCont :input").eq(7).val() >= 2)&&  ($(".sliderCont :input").eq(7).val() <= 12)) ? $(".sliderCont :input").eq(7).val(Number($(".sliderCont :input").eq(7).val()).toFixed(2).substring(0, 6)) : $(".sliderCont :input").eq(7).val('');
        $(".sliderCont :input").eq(2).val((Number($(".sliderCont :input").eq(1).val()) / 2).toFixed(2));
        $(".sliderCont :input").eq(3).val((Number($(".sliderCont :input").eq(1).val()) / Number($(".sliderCont :input").eq(0).val())).toFixed(2));
        
         
        $(".sliderCont :input").eq(6).val((Number($(".sliderCont :input").eq(4).val()) * Number($(".sliderCont :input").eq(5).val()) / 60).toFixed(2));
        $(".sliderCont :input").eq(8).val((Number($(".sliderCont :input").eq(3).val())).toFixed(2));
        $(".sliderCont :input").eq(9).val((Number($(".sliderCont :input").eq(3).val())).toFixed(2));
        $(".sliderCont :input").eq(10).val((Number($(".sliderCont :input").eq(0).val())));
        $(".sliderCont :input").eq(12).val((Number($(".sliderCont :input").eq(1).val())).toFixed(2));
        $(".sliderCont :input").eq(13).val((Number($(".sliderCont :input").eq(9).val()) * Number($(".sliderCont :input").eq(11).val())).toFixed(2));
        $(".sliderCont :input").eq(14).val((Number($(".sliderCont :input").eq(2).val())).toFixed(2));
        $(".sliderCont :input").eq(15).val((Number($(".sliderCont :input").eq(13).val()) / 2).toFixed(2));
        $(".sliderCont :input").eq(16).val((Number($(".sliderCont :input").eq(7).val())).toFixed(2));
        $(".sliderCont :input").eq(17).val((Number($(".sliderCont :input").eq(7).val())).toFixed(2));
        $(".sliderCont :input").eq(18).val((Number($(".sliderCont :input").eq(14).val()) * Number($(".sliderCont :input").eq(16).val()) / 100).toFixed(2));
        $(".sliderCont :input").eq(19).val((Number($(".sliderCont :input").eq(15).val()) * Number($(".sliderCont :input").eq(17).val()) / 100).toFixed(2));
        $(".sliderCont :input").eq(20).val((365 / Number($(".sliderCont :input").eq(10).val())).toFixed(2));
        $(".sliderCont :input").eq(21).val((365 / Number($(".sliderCont :input").eq(11).val())).toFixed(2));
        $(".sliderCont :input").eq(22).val((Number($(".sliderCont :input").eq(20).val()) * Number($(".sliderCont :input").eq(4).val()) * Number($(".sliderCont :input").eq(5).val()) / 60).toFixed(2));
        $(".sliderCont :input").eq(23).val((Number($(".sliderCont :input").eq(21).val()) * Number($(".sliderCont :input").eq(4).val()) * Number($(".sliderCont :input").eq(5).val()) / 60).toFixed(2));
        $(".sliderCont :input").eq(24).val(Number($(".sliderCont :input").eq(18).val()) + Number($(".sliderCont :input").eq(22).val()));
        $(".sliderCont :input").eq(25).val(Number($(".sliderCont :input").eq(19).val()) + Number($(".sliderCont :input").eq(23).val()));
    }


    if ($(".sliderCont :input").eq(0).val() == "") {
        $(".sliderCont :input").eq(2).val("");
        $(".sliderCont :input").eq(10).val("");
        $(".sliderCont :input").eq(20).val("");
        $(".sliderCont :input").eq(21).val("");
    }
    if ($(".sliderCont :input").eq(1).val() == "") {
        $(".sliderCont :input").eq(3).val("");
        $(".sliderCont :input").eq(12).val("");
        $(".sliderCont :input").eq(13).val("");
        $(".sliderCont :input").eq(14).val("");
        $(".sliderCont :input").eq(15).val("");
    }
    if ($(".sliderCont :input").eq(4).val() == "") {
        $(".sliderCont :input").eq(6).val("");
    }

    if ($(".sliderCont :input").eq(5).val() == "") {
        $(".sliderCont :input").eq(6).val("");
    }
    if ($(".sliderCont :input").eq(11).val() == "") {
        $(".sliderCont :input").eq(9).val("");
        $(".sliderCont :input").eq(21).val("");
    }
    if ($(".sliderCont :input").eq(0).val() == "0") {
        $(".sliderCont :input").eq(0).val("");
        $(".sliderCont :input").eq(10).val("");
        $(".sliderCont :input").eq(20).val("");
        $(".sliderCont :input").eq(21).val("");
//        $(".sliderCont :input").eq(1).val("");
//        $(".sliderCont :input").eq(2).val("");
        $(".sliderCont :input").eq(3).val("");
    }
    if ($(".sliderCont :input").eq(1).val() == "0") {
//        $(".sliderCont :input").eq(0).val("");
        $(".sliderCont :input").eq(1).val("");
        $(".sliderCont :input").eq(2).val("");
        $(".sliderCont :input").eq(3).val("");
        $(".sliderCont :input").eq(12).val("");
        $(".sliderCont :input").eq(13).val("");
        $(".sliderCont :input").eq(14).val("");
        $(".sliderCont :input").eq(15).val("");
    }
    if ($(".sliderCont :input").eq(4).val() == "0") {
        $(".sliderCont :input").eq(4).val("");
//        $(".sliderCont :input").eq(5).val("");
        $(".sliderCont :input").eq(6).val("");

    }
    if ($(".sliderCont :input").eq(5).val() == "0") {
//        $(".sliderCont :input").eq(4).val("");
        $(".sliderCont :input").eq(5).val("");
        $(".sliderCont :input").eq(6).val("");
    }
    if (($(".sliderCont :input").eq(7).val() == "0") || ($(".sliderCont :input").eq(7).val() == "")) {
        $(".sliderCont :input").eq(7).val("");
        $(".sliderCont :input").eq(16).val("");
        $(".sliderCont :input").eq(17).val("");

    }

    if ($(".sliderCont :input").eq(11).val() == "0") {
//        $(".sliderCont :input").eq(8).val("");
//        $(".sliderCont :input").eq(9).val("");
//        $(".sliderCont :input").eq(10).val("");
        $(".sliderCont :input").eq(11).val("");
//        $(".sliderCont :input").eq(12).val("");
//        $(".sliderCont :input").eq(13).val("");
//        $(".sliderCont :input").eq(14).val("");
//        $(".sliderCont :input").eq(15).val("");
//        $(".sliderCont :input").eq(16).val("");
//        $(".sliderCont :input").eq(17).val("");
//        $(".sliderCont :input").eq(18).val("");
//        $(".sliderCont :input").eq(19).val("");
//        $(".sliderCont :input").eq(20).val("");
        $(".sliderCont :input").eq(21).val("");
//        $(".sliderCont :input").eq(22).val("");
        $(".sliderCont :input").eq(23).val("");
//        $(".sliderCont :input").eq(24).val("");
        $(".sliderCont :input").eq(25).val("");

    }
    if ($(".sliderCont :input").eq(26).val() == "0") {
        $(".sliderCont :input").eq(26).val("");

    }
macroModels.prototype.nanChecker(slide);

};
macroModels.prototype.nanChecker = function(ind){
     $(".sliderCont .questionSet").eq(ind).find("input[disabled]").each(function(){
        if((Number($(this).val())=== 0) || ($(this).val() === "NaN") || ($(this).val() === "Infinity")){
            $(this).val("");
        }
        else{
            if($(this).val().indexOf(".")!== -1){
                 $(this).val($(this).val().substring(0, 6));
            }
            else{
                $(this).val($(this).val().substring(0, 5));
            }
            
        }
       
     });
}
macroModels.prototype.numericChecker = function () {
    $('input').bind('keypress', function (event, val) {
        var regex = new RegExp("^\\d*\\.?\\d{0,}$");
        var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    });

}

macroModels.prototype.roundOff = function () {
    $('input').unbind('keyup').bind('keyup', function (event) {
        var inputValue7 = $(".sliderCont :input").eq(7).val();
        var inputValueRound7 = ($(".sliderCont :input").eq(7).val().length > 2) ? Math.round(inputValue7).toFixed(2) : "";
    });

};


macroModels.prototype.controlTab = function () {
    $("ul > li.active").children().attr("tabindex", "-1");

    $("ul > li").on("click", function () {
        
        setTimeout(function () {
            
            if ($("ul > li.active").children().attr("aria-expanded") == "true") {
                //setTimeout(function(){alert(0);$("#jxgbox > svg").attr("tabindex","0").focus()},250)
                $("ul > li").children().removeAttr("tabindex");
                $("ul > li.active").children().attr("tabindex", "-1");
            }

        }, 250);
        setTimeout(function () {
           /* $(".tab2").attr("role","alert");
            $(".tab0").children().find("section").eq(0).attr("tabindex", "0").focus();*/
            $(".tab-pane").attr("role","alert");
        }, 400);
        
        
        setTimeout(function () {
            $(".navigation").attr("tabindex", "0").focus();
        }, 700);


    });
};



var str = "";
macroModels.prototype.lastValidation = function (id) {
      var errorMargin = 1;
    var total = Math.round(365 / (Number($(".sliderCont :input").eq(3).val()) * 365 / (Math.pow((2 * Number($(".sliderCont :input").eq(3).val()) * 365 * Number($(".sliderCont :input").eq(5).val()) * Number($(".sliderCont :input").eq(4).val()) / (60 * Number($(".sliderCont :input").eq(7).val()) / 100)), 0.5))));
    $(".sliderCont :input").eq(26).focusout(function () {
        if ($(this).val().length > 0) {
            if ((Number($(this).val()) !== 'NaN') &&(Number($(this).val()) >= (total - errorMargin)) && (Number($(this).val()) <= (total + errorMargin))) {
                str = '<p>Correct !</p><br><p>According to the Baulin-Tobin Model, you should take out ' + (Number($(".sliderCont :input").eq(8).val()) * (total)).toFixed(2) + '</p><p>and allow   ' + (total) + '</p><p>days between visits.</p><p>But you report that you take out   ' + Number($(".sliderCont :input").eq(12).val()).toFixed(2) + '</p><p>and visit the bank every   ' + Number( $(".sliderCont :input").eq(10).val()).toFixed(2) + '</p><p>days.</p><p>Can you explain why your behavior does not match that predicted by the model? Are you going to change your behavior?<p/>';
            }
            else {
                str = '<p>Really? I calculated the optimal number as      ' + (total).toFixed(0) + '</p><br><p>Maybe you should try to optimize again.</p>'
            }
        }
        if ($(".sliderCont :input").eq(26).val() == "0") {
            setTimeout(function () {
                $(".sliderCont .questionSet:last").find(".sliderfooter").html("");
            }, 50)


        }
        $(".sliderCont .questionSet:last").find(".sliderfooter").html(str);
        setTimeout(function(){
            $(".sliderfooter").attr("tabindex","0").focus();
        },1000)

    });


}
macroModels.prototype.validateInput = function (slide) {

    var flag = false;
    $(".sliderCont .questionSet").eq(slide).find(":input:not([disabled])").each(function (e) {
        if ($(this).val().length > 0) {
            if (Number($(this).val()) !== 'NaN') {
                flag = true;
            }
            else {
                flag = false;
                return false;
            }
        } else {
            flag = false;
            return false;
        }
    });
    return flag;
};

$(function () {
    Model = new macroModels();
    Model.LoadXML();
    demo.Init();
});

var Model;