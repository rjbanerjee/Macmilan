/**
 * Main _Contructor Function of this Application.
 */
function macroModels() {
    this._xmlFileName = "Activity.xml";
    this._xmlFilePath = "./xml/";
    this._xmlObject = null;
    this._activityTitle = null;
}

/**
 * Function Loads the Macromodel Activity XML from the configured parameters in _Constructor.
 * The Function Store the XML Object in the Defined Variable in _Constructor.
 */
macroModels.prototype.LoadXML = function () {
    //Loading XML File.
    this._xmlObject = loadXMLDoc(this._xmlFilePath + this._xmlFileName);
    //Parsing XML String.
    this._xmlObject = parseXMLString(this._xmlObject);
    //The Main DOM is been added in Object.
    this._xmlObject = this._xmlObject.getElementsByTagName("activity")[0];
    this.GenerateHTML();
    this.controlTab();
}

/**
 * [[Description]]
 */


macroModels.prototype.GenerateHTML = function () {
    // stri  
    //Title Name
    this._activityTitle = this._xmlObject.getElementsByTagName("heading")[0].childNodes[0].nodeValue;
    $("title").html(this._activityTitle);
    $(".modelTitle a").html(this._activityTitle);
    $(".questionHolder p").html(this._xmlObject.getElementsByTagName("question")[0].childNodes[0].nodeValue);
    var _activityTabs = this._xmlObject.getElementsByTagName("section");
    var _activityTabsCount = this._xmlObject.getElementsByTagName("section").length;

    for (i = 0; i < _activityTabsCount; i++) {
        $(".nav li:eq(" + i + ") a").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "content") {
           // $(".tab-pane :eq(" + i + ") h3").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

            $(".tab-pane :eq(" + i + ") p").html(this._xmlObject.getElementsByTagName("section")[0].childNodes[1].textContent);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContent") {
//                    console.log(this._xmlObject.getElementsByTagName("rangeOptions").childNodes)
//                      var _activityQestionRangeCount = this._xmlObject.getElementsByTagName("rangeOptions");
//                      alert(_activityQestionRangeCount[0].getElementsByTagName("options").length); 
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[1].childNodes[1].textContent);
            var xmlObj = this._xmlObject;
            var sliderObjCounter = 0;
            var quesparameter = '';
            var exogenousrangeparameter = '';
            var exogenousparameter = '';
            var shockparameter = '';
            $(xmlObj).find("rangeOptions").find("options").each(function (e) {
                quesparameter += '<div class="rangeShell"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled="true" title = "Parameter ' + $(this).find("title").text() + ' slider" value="' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '" class="rhinput"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("." + $(xmlObj).find("rangeOptions").attr("id")).html(quesparameter);
            $(xmlObj).find("exogenousrange").find("options").each(function (e) {
                exogenousrangeparameter += '<div class="rangeShell"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input title = "Exogenous ' + $(this).find("title").text() + ' slider" type="text" disabled="true" value="' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '" class="rhinput"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("." + $(xmlObj).find("exogenousrange").attr("id")).html(exogenousrangeparameter);
            $(xmlObj).find("shockRange").find("options").each(function (e) {
                shockparameter += '<div class="rangeShell"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input title = "Shock To ' + $(this).find("title").text() + ' slider" type="text" disabled="true" value="' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '" class="rhinput"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + (Number($(this).find("minLimit").text()) + Number($(this).find("maxLimit").text())) / 2 + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("." + $(xmlObj).find("shockRange").attr("id")).html(shockparameter);
            var baselineUp = '';
            var baseline = '';
            $(xmlObj).find("exogenousOptions").find("options").each(function (e) {
                baselineUp += '<div class="set"> <label for="' + $(this).find("title").text() + '" class="italics">' + $(this).find("title").text() + '</label><input type="text" disabled id="' + $(this).find("title").text() + '" value="'+$(this).find("minLimit").text()+'"></div>';
                baseline += '<div class="set"> <label><span class="italics">' + $(this).find("title").text() + '</span><span class="separetor">=</span>'+$(this).find("minLimit").text()+'</label></div>';
            });
             exogenousparameter += '<div class="inputHolder">' + baselineUp + '</div>';
            exogenousparameter += '<div class="descHolder"><span class="descHolderHeader">Baseline</span>' + baseline + '</div>';
            $("." + $(xmlObj).find("exogenousOptions").attr("id")).html(exogenousparameter);


        }
    }
     setTimeout(function () {
         $("svg").before("<span class = 'hiddenText1'>This is a Model of the Open Economy Graph</span>");
        $("svg").attr("focusable","false");
        $("li > a").blur();
           $(".tab-pane").attr("role", "alert");
        }, 200);
    this.Event();
};
macroModels.prototype.controlTab = function () {
    $("ul > li.active").children().attr("tabindex", "-1");
    
    $("ul > li").on("click",function () {

        setTimeout(function () {
            if ($("ul > li.active").children().attr("aria-expanded") == "true") {
                 //setTimeout(function(){alert(0);$("#jxgbox > svg").attr("tabindex","0").focus()},250)
                $("ul > li").children().removeAttr("tabindex");
                $("ul > li.active").children().attr("tabindex", "-1");
            }

        }, 250);
         setTimeout(function () {
           $(".tab-pane").attr("role", "alert");
        }, 500);
       

    });
};

/**
 * The Application On Ready Initialise. 
 * Create the Main Object Class.
 */

macroModels.prototype.Event = function () {
    var parameter = false;
    //question parameter click && parameter back click
    $(".param,.introback").off("click").on("click", function () {
        parameter = !parameter;
        // Can add another method and properties
        if (parameter) {
            $(".introHolder").removeClass('elementShow').addClass('elementHide');
            $(".rangeholder").removeClass('elementHide').addClass('elementShow');
             $(".introback").attr("tabIndex", "0").focus();
            $(".rangeholder").removeAttr("aria-hidden","false");
            /*$(".rangeholder").find(".introback").attr({"tabindex": "0","aria-hidden":"false"});
            $(".rangeholder").find(".introback").removeAttr("disabled","disabled");*/
            setTimeout(function(){$(".rangeholder").attr("role","alert")},250);     
        }
        else {
            $(".rangeholder").removeClass('elementShow').addClass('elementHide');
            $(".introHolder").removeClass('elementHide').addClass('elementShow');
            $(".param").attr("tabIndex", "0").focus();
           /* $(".rangeholder").find(".introback").attr({"tabindex": "-1","aria-hidden":"true"});
            $(".rangeholder").find(".introback").attr("disabled","disabled");*/
            setTimeout(function(){$(".introHolder").attr("role","alert")},250);
        }
    });
}


$(function () {
    Model = new macroModels();
    Model.LoadXML();
    demo.Init();
});

var Model;