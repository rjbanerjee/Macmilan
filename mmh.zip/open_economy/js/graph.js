var demo = {};
var board;
var board1;
var IData;
var SData;

var userData = {};
userData.NSL = 750; // 650 to 850
userData.WRIR = 8.00; //7.50 to 8.50
userData.Inv = 0; //-150 to 150
userData.NX = -100; //-150 to 150
userData.IEID = -3.50; //-3.50 to //-2.50
userData.SNEIR = -320; // -440 to -320

userData.I = 750;
userData.Nx = 0;
userData.r = 1.00;
userData.rYAxis=20;


function calDerivedData() {
    //Calculating I
    userData.I = Math.round((userData.WRIR - 8) * (userData.IEID * 100) / 1.06666666666666 + 750 + userData.Inv);
    //Calculating Nx
    userData.Nx = userData.NSL - userData.I;
    //Calculating r
    userData.r = Math.round(1 + (userData.Nx - userData.NX) / userData.SNEIR * 100) / 100;
}
;

//X Axis Value Conversion
var xValConvert = function (x) {
    var min = 600;
    var max = 900;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 6;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//Y Axis Value Conversion
var yValConvert = function (y) {
    var min = 7.50;
    var max = 8.50;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 10;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};
/*second graph conversion*/

//X Axis Value Conversion
var xSecondValConvert = function (x) {
    var min = -170;
    var max = 170;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 10;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
     return xLinePoint;
};

//Y Axis Value Conversion
var ySecondValConvert = function (y) {
    var min = 0.70;
    var max = 1.30;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 6;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
   // console.log(yLinePoint)
    return yLinePoint;
};


//X Axis Value Rev Conversion
var xValRevConvert = function (x) {
    var min = 600;
    var max = 900;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 6;

    var xLinePoint = ((diff / maxSlide) * x);
    return min + xLinePoint;
};

//Y Axis Value Rev Conversion
var yValRevConvert = function (y) {
    var min = 7.50;
    var max = 8.50;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 10;

    var yLinePoint = ((diff / maxSlide) * y);
    return min + yLinePoint;
};

//X Axis Value Rev Conversion
var xSecondValRevConvert = function (x) {
    var min = -170;
    var max = 170;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 10;

    var xLinePoint = ((diff / maxSlide) * x);
    return min + xLinePoint;
};

//Y Axis Value Rev Conversion
var ySecondValRevConvert = function (y) {
    var min = 0.7;
    var max = 1.3;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 10;

    var yLinePoint = ((diff / maxSlide) * y);
    return min + yLinePoint;
};

demo.Init = function () {

    board = JXG.JSXGraph.initBoard('box', {
        axis: false,
        boundingbox: [-0.7, 10.5, 6, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    var xaxis = board.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '900',
        straightFirst: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        straightLast: true,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    var yaxis = board.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        lastArrow: false,
        withLabel: true,
                name: '600',
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [0, -180] // (in pixels)
                },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var t1 = board.create('text', [-0.7, 10, "8.50"]);
    var t2 = board.create('text', [-0.7, 5, "r (%)"], {cssClass:'italics'});
    var t3 = board.create('text', [-0.7, 0.5, "7.50"]);
     var redLineStarComple = board.create('line', [[xValConvert(600), function () {
                 return yValConvert(userData.WRIR);
            }], [xValConvert(900), function () {
                return yValConvert(userData.WRIR);
            }]], {
        strokeWidth: 1.5,
        strokeColor: 'red',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "r*'",
        withLabel: true,
        label: {offset: [240,15],cssClass:"italics"}
    });
    var redLineStar = board.create('line', [[xValConvert(600), yValConvert(8.0)], [xValConvert(900), yValConvert(8.0)]], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "r*",
        withLabel: true,
        label: {offset: [240, 15],cssClass:"italics"}
    });
    var greenLineSComple = board.create('line', [[function () {
                return xValConvert(userData.NSL);
            }, yValConvert(7.5)], [function () {
                return xValConvert(userData.NSL);
            }, yValConvert(9)]], {
        strokeWidth: 1.5,
        strokeColor: 'red',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "S'",
        withLabel: true,
        label: {offset: [10, 200],cssClass:"italics"}
    });
    var greenLineS = board.create('line', [[xValConvert(750), yValConvert(7.5)], [xValConvert(750), yValConvert(9)]], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "S",
        withLabel: true,
        label: {offset: [10, 200],cssClass:"italics"}
    });

    var redLineStar2 = board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
          //  console.log(x)
            return yValConvert(8 + ((x - 750 - userData.Inv) / (userData.IEID * 100) * 1.06666666666666));
        }, xValConvert(600), xValConvert(900)], {
        strokeWidth: 1.5,
        strokeColor: 'red',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "I'",
        withLabel: true,
        label: {offset: [25, 20],cssClass:"italics"}
    });

    var redLineStar1 = board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
            return yValConvert(8 + ((x - 750) / (userData.IEID * 100) * 1.06666666666666));
        }, xValConvert(600), xValConvert(900)], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "I",
        withLabel: true,
        label: {offset: [25, 20],cssClass:"italics"}
    });
    board1 = JXG.JSXGraph.initBoard('box1', {
        axis: false,
        boundingbox: [-1.2, 6, 10, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });

    var xaxis1 = board1.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '900',
        strokeColor: '#606060',
        strokeWidth: 2,
        straightFirst: false,
        straightLast: true,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0}
    });
    var yaxis1 = board1.create('axis', [[0, 0], [0, 1]],
            {name: 'y',
               straightFirst: false,
                straightLast: true,
                firstArrow: false,
                lastArrow: false,
             strokeColor: '#606060',
        strokeWidth: 2,
                withLabel: true,
                        label: {
                            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                            offset: [0, -180]   // (in pixels)
                        },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: '#008000',
                    majorHeight: 0}
            });






    /***********************Secong Graph********************************/
    var greenLineSComple = board1.create('line', [[function () {
                  return (xSecondValConvert(userData.Nx) < 0)?-3:xSecondValConvert(userData.Nx);
            }, ySecondValConvert(0.70)], [function () {
                return (xSecondValConvert(userData.Nx) < 0)?-3:xSecondValConvert(userData.Nx);
            }, ySecondValConvert(1.30)]], {
        strokeWidth: 1.5,
        strokeColor: 'red',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "S-I'",
        withLabel: true,
        label: {offset: [10,50],cssClass:"italics"}
    });
    var greenLineS = board1.create('line', [[xSecondValConvert(0), ySecondValConvert(0.70)], [xSecondValConvert(0), ySecondValConvert(1.30)]], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "S-I",
        withLabel: true,
        label: {offset: [10, 50],cssClass:"italics"}
    });

    var redLineStar2 = board1.create('functiongraph', [function (x) {
            x = xSecondValRevConvert(x);
            return ySecondValConvert(1+(x-(userData.NX))/userData.SNEIR);
       }, xSecondValConvert(-170), xSecondValConvert(170)], {
        strokeWidth: 1.5,
        strokeColor: 'red',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "NX'",
        withLabel: true,
        label: {offset: [50, -100],cssClass:"italics"}
    });

    var redLineStar1 = board1.create('functiongraph', [function (x) {
            x = xSecondValRevConvert(x);
                return ySecondValConvert(1+(x-(userData.NX)/2)/(userData.SNEIR+(userData.NX)));
        }, xSecondValConvert(-170), xSecondValConvert(170)], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "NX",
        withLabel: true,
        label: {offset: [50, -100],cssClass:"italics"}
    });

    var t1 = board1.create('text', [-1.2, 6, "1.30"]);
    var t2 = board1.create('text', [-1, 3, "&#x03B5"], {cssClass:'italics'});
    var t3 = board1.create('text', [-1.1, 2.5, ""]);
    var t4 = board1.create('text', [-1.2, 0.4, "0.70"]);





    this.sliderChange();
};

demo.sliderChange = function () {

    $("input[id^='ex']").each(function () {
        $(this).initiateSlider();
    });
};

$.fn.initiateSlider = function () {
    var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
            var vElmValue = (parseInt(value) === value) ? value : value.toFixed(2);
            oThisElm.parent().parent().find(".rhinput").val(vElmValue);
            demo.fieldUpdation();
            return 'Current value: ' + value;

        }
    });
}

demo.fieldUpdation = function () {
    $("svg").attr("focusable", "false");
    $(".intro .rholder .rhinput")[0].value = Number($(".intro .rholder .rhinput")[0].value).toFixed(2);
    $(".block01 .rholder .rhinput")[2].value = Number($(".block01 .rholder .rhinput")[2].value).toFixed(2);
    //endogenoues consumption calculation
    $("#I").val(Math.round((Number($(".block01 .rholder .rhinput")[2].value) - 8) * (Number($(".intro .rholder .rhinput")[0].value) * 100) / 1.06666666666666 + 750 + Number($(".block02 .rholder .rhinput")[0].value)));
    //endogenoues investment calculation
    $("#NX").val(Math.round(Number($(".block01 .rholder .rhinput")[0].value) - $("#I").val()));
    //endogenoues investment calculation
    $("#r").val((1 + ($("#NX").val() - Number($(".block02 .rholder .rhinput")[2].value)) / Number($(".intro .rholder .rhinput")[2].value)).toFixed(2));
    demo.graphManupulation();
};

demo.graphManupulation = function () {
    userData.NSL = Number($(".block01 .rholder .rhinput")[0].value); // 650 to 850
    userData.WRIR = Number($(".block01 .rholder .rhinput")[2].value); //7.50 to 8.50
    userData.Inv = Number($(".block02 .rholder .rhinput")[0].value); //-150 to 150
    userData.NX = Number($(".block02 .rholder .rhinput")[2].value); //-150 to 150
    userData.IEID = Number($(".intro .rholder .rhinput")[0].value); //-3.50 to //-2.50
    userData.SNEIR = Number($(".intro .rholder .rhinput")[2].value); // -440 to -320

    userData.I = $("#I").val();
    userData.Nx = $("#NX").val();
    userData.r = $("#r").val();
    
     calDerivedData();
    board.fullUpdate();
    board1.fullUpdate();
};