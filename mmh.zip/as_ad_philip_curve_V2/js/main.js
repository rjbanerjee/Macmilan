/**
 * Main _Contructor Function of this Application.
 */
function macroModels() {
    this._xmlFileName = "Activity.xml";
    this._xmlFilePath = "./xml/";
    this._xmlObject = null;
    this._activityTitle = null;
    this._activityYear = 2001;
    
}

/**
 * Function Loads the Macromodel Activity XML from the configured parameters in _Constructor.
 * The Function Store the XML Object in the Defined Variable in _Constructor.
 */
macroModels.prototype.LoadXML = function () {
    //Loading XML File.
    this._xmlObject = loadXMLDoc(this._xmlFilePath + this._xmlFileName);
    //Parsing XML String.
    this._xmlObject = parseXMLString(this._xmlObject);
    //The Main DOM is been added in Object.
    this._xmlObject = this._xmlObject.getElementsByTagName("activity")[0];
    this.GenerateHTML();
    this.controlTab();
}

/**
 * [[Description]]
 */


macroModels.prototype.GenerateHTML = function () {
    //Title Name
    this._activityTitle = this._xmlObject.getElementsByTagName("heading")[0].childNodes[0].nodeValue;
    $("title").html(this._activityTitle);
    $(".modelTitle a").html(this._activityTitle);
    $(".questionHolder p").html(this._xmlObject.getElementsByTagName("question")[0].childNodes[0].nodeValue);
    var _activityTabsCount = this._xmlObject.getElementsByTagName("section").length;
    for (i = 0; i < _activityTabsCount; i++) {
        $(".nav li:eq(" + i + ") a").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "content") {
            $(".tab-pane :eq(" + i + ") p").html(this._xmlObject.getElementsByTagName("section")[0].childNodes[1].textContent);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContent") {
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[1].childNodes[1].textContent);
            var xmlObj = this._xmlObject;
            var quesparameter = '';
            var that = this;
            $(xmlObj).find("rangeOptions").find("options").each(function (e) {
                quesparameter += '<div class="rangeShell"><div class="rholder" id = "title' + (e + 1) + '" aria-label = "' + $(this).find("title").text() + '"><h5>' + $(this).find("title").text() + " <span class='rangeYear'>" + that._activityYear + '</span><span class = "hiddenText">TextBox</span></h5></div><div class="rholder"><span class="minRange">' + $(this).find("minLimit").text() + '</span><input type="text" class="modelInput" value="' + $(this).find("value").text() + '"/><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
            });
            $("." + $(xmlObj).find("rangeOptions").attr("id")).html(quesparameter);
        }
    }
    $(".controlSection").hide();

    setTimeout(function () {
        $("svg").before("<span class = 'hiddenText1'>This is a AS-AD Model and the Philips Curve Graph</span>");
        $("svg").attr("focusable", "false");
        $("li > a").blur();
        $(".tab-pane").attr("role", "alert");
    }, 200);
    setTimeout(function(){
        $(".exogenousRange").attr("role", "alert");
    },1500)



    this.Event();
};
macroModels.prototype.controlTab = function () {
    $("ul > li.active").children().attr("tabindex", "-1");

    $("ul > li").on("click", function () {

        // Can add another method and properties
        if ($(this).index() !== 0) {
            $(".controlSection").show();
            if($(this).index() === 1){
                $(".graphHolderFirst").show();
                $("#diagram").hide();
            }
            else{
                $(".graphHolderFirst").hide();
                $("#diagram").show();
            }
        } else {
            $(".controlSection").hide();
        }
        setTimeout(function () {
            if ($("ul > li.active").children().attr("aria-expanded") == "true") {
                //setTimeout(function(){alert(0);$("#jxgbox > svg").attr("tabindex","0").focus()},250)
                $("ul > li").children().removeAttr("tabindex");
                $("ul > li.active").children().attr("tabindex", "-1");
                if ($("ul > li.active").children().attr("href") == "Graph01") {
                    $(".controlSection").attr("role", "alert");
                }
            }

        }, 250);
        setTimeout(function () {
            $(".tab-pane").attr("role", "alert");
        }, 500);
        setTimeout(function () {
            $(".controlSection").attr("tabindex", "0").focus();
        }, 5000);


    });
};

/**
 * The Application On Ready Initialise. 
 * Create the Main Object Class.
 */

macroModels.prototype.Event = function () {
    var parameter = false;
    //question parameter click && parameter back click
    $(".param,.introback").off("click").on("click", function () {
        parameter = !parameter;
        // Can add another method and properties
        if (parameter) {
            $(".introHolder").removeClass('elementShow').addClass('elementHide');
            $(".rangeholder").removeClass('elementHide').addClass('elementShow');
            $(".introback").attr("tabIndex", "0").focus();
            $(".rangeholder").removeAttr("aria-hidden", "false");
            setTimeout(function () {
                $(".rangeholder").attr("role", "alert");
            }, 250);
        }
        else {
            $(".rangeholder").removeClass('elementShow').addClass('elementHide');
            $(".introHolder").removeClass('elementHide').addClass('elementShow');
            $(".param").attr("tabIndex", "0").focus();
            setTimeout(function () {
                $(".introHolder").attr("role", "alert");
            }, 250);
        }
    });
    this.createPredaterminedVariable();
    this.createParameterTable();
    this.createEndogenousTable();
    _previousYear = [{
                'val1': Number($(".modelInput").eq(0).val()),
                'val2': Number($(".modelInput").eq(1).val()),
                'val3': Number($(".modelInput").eq(2).val()),
                'val4':  Number($(".modelInput").eq(3).val())
            }]
}
var yearCalculation = [],_previousYear =[];
macroModels.prototype.createPredaterminedVariable = function () {
    var that = this;
    var table = '';
    var header = ['Previous period’s inflation &nbsp; (π<sub>t-1</sub>)'];
    var startYearData = ["2.00"];
    table = $('<table></table>');
    for (var i = 0; i <= 1; i++) {
        var row = $('<tr></tr>');
        for (var j = 0; j < 17; j++) {
            var column;

            if (i === 0) {
                if (j !== 0) {
                    column = $('<th class="elementHide"></th>').text(that._activityYear - (2 - j));
                    yearCalculation[j] = that._activityYear - (2 - j);
                }
                else {
                    column = $('<th  class="heading"></th>').text("");
                    yearCalculation[j] = 0;
                }
            }
            else {
                if (j === 0) {
                    column = $('<td class="heading"></td>').html(header[i - 1]);
                }
                else {
                    column = $('<td class="predVarCol elementHide"></td>').text(startYearData[(i - 1)]);
                }
            }
            table.append(row);
            row.append(column);
        }
    }
    $('.predVar').html(table);
    //this.showTable($.inArray(that._activityYear, yearCalculation), '.predVar');
    //this.bindEvent($.inArray(that._activityYear, yearCalculation));
};
macroModels.prototype.createParameterTable = function () {
    var that = this;
    var table = '';
    var header = ['Responsiveness of demand to the real interest rate (α)', 'Natural rate of interest (ρ)', 'Responsiveness of inflation to output in the Phillips Curve (φ)', 'Responsiveness of i to inflation in the monetary-policy rule (θ<sub>π</sub>)', 'Responsiveness of i to output in the monetary-policy rule(θ<sub>Y</sub>)', 'A=(αθ_π)/(1+αθ_Y)', 'B=1/(1+αθ_Y)'];
    var parameterClass = ['demandrate', 'naturalrate', 'inflationrate', 'monetarypolicyrate', 'monetarypolicyrule', 'ParameterA', 'ParameterB'];
    var startYearData = ["1.00", "2.00", "0.25", "0.50", "0.50", "11.00", "11.00"];
    table = $('<table></table>');

    for (var i = 0; i <= 7; i++) {
        var row = $('<tr></tr>');
        for (var j = 0; j < 17; j++) {
            var column;

            if (i === 0) {
                if (j !== 0) {
                    column = $('<th class="elementHide"></th>').text(that._activityYear - (2 - j));
                    yearCalculation[j] = that._activityYear - (2 - j);
                }
                else {
                    column = $('<th  class="heading"></th>').text("");
                    yearCalculation[j] = 0;
                }
            }
            else {
                if (j === 0) {
                    column = $('<td class="heading"></td>').html(header[i - 1]);
                }
                else {
                    if (j === 1) {
                        if (i < 6) {
                            column = $('<td class="' + parameterClass[i - 1] + ' elementHide"></td>').html('<input type="text" class="tableModelInput" value="' + startYearData[(i - 1)] + '"/>');
                        }
                        else {
                            column = $('<td class="' + parameterClass[i - 1] + ' elementHide"></td>').text(startYearData[(i - 1)]);
                        }
                    }
                    else {
                        column = $('<td class="' + parameterClass[i - 1] + ' elementHide"></td>').text(startYearData[(i - 1)]);
                    }
                }
            }
            table.append(row);
            row.append(column);
        }
    }
    $('.parameterTableView').html(table);
    //this.showTable($.inArray(that._activityYear, yearCalculation), '.parameterTableView');
    //this.bindEvent($.inArray(that._activityYear, yearCalculation));
};
macroModels.prototype.createEndogenousTable = function () {
    var that = this;
    var table = '';
    var header = ['Output(Y<sub>t</sub>)', 'Inflaton(π<sub>t</sub>)', 'Nominal interest rate(i<sub>t</sub>)', 'Expected inflation (E<sub>t</sub>π<sub>t+1</sub>)', 'Real interest rate (r<sub>t</sub>)'];
    var parameterClass = ['output', 'inflaton', 'nominalinterestrate', 'expectedinflation', 'realinterestrate'];
    var startYearData = ["100.00", "2.00", "4.00", "2.00", "2.00"];
    table = $('<table></table>');

    for (var i = 0; i <= 5; i++) {
        var row = $('<tr></tr>');
        for (var j = 0; j < 17; j++) {
            var column;

            if (i === 0) {
                if (j !== 0) {
                    column = $('<th class="elementHide"></th>').text(that._activityYear - (2 - j));
                    yearCalculation[j] = that._activityYear - (2 - j);
                }
                else {
                    column = $('<th  class="heading"></th>').text("");
                    yearCalculation[j] = 0;
                }
            }
            else {
                if (j === 0) {
                    column = $('<td class="heading"></td>').html(header[i - 1]);
                }
                else {
                    column = $('<td class="' + parameterClass[i - 1] + ' elementHide"></td>').text(startYearData[(i - 1)]);
                }
            }
            table.append(row);
            row.append(column);
        }
    }
    $('.tableView').html(table);
    //this.showTable($.inArray(that._activityYear, yearCalculation), '.tableView');
    this.bindEvent($.inArray(that._activityYear, yearCalculation));
};

macroModels.prototype.showTable = function (ind, obj) {
    //$('.tableView tr th,.tableView tr td').addClass("elementHide");
    $(obj).find('tr th').addClass("elementHide");
    $(obj).find('tr td').addClass("elementHide");
    $(".heading").removeClass("elementHide");
    for (var i = 0; i < $(obj).find('tr').length; i++) {
        for (var j = (ind - 2); j <= ind; j++) {
            $(obj).find('tr').eq(i).children().eq(j).removeClass("elementHide");
//            if (i > 3) {
//                $(obj).find('tr').eq(i).children().eq(ind).addClass("elementHide");
//            }
        }
    }
    //this.bindEvent(ind);
};
macroModels.prototype.bindEvent = function (ind) {

    var that = this;

    $(".modelInput").off("focusin").on("focusin", function () {
        $(this).attr("aria-label", $(this).parent().siblings().text());
        that.inputFocusEventBind($(this), ind);
    });
    $(".modelInput").off("focusout").on("focusout", function () {
        that.inputFocusEventBind($(this), ind);
    });
    $(".modelInput").eq(3).off("keypress").on("keypress", function (e) {
        if (e.keyCode === 13)
        {
            that.inputFocusEventBind($(this), ind);
           
            if ($.inArray(that._activityYear + 1, yearCalculation) === -1)
                return false;
             
            that._activityYear++;
            
            $(".rangeYear").html(that._activityYear);
            $(".modelInput").each(function (e) {
                if (e === 0) {
                    $(this).val((Number(100)).toFixed(2))
                }
                else if (e === 1){
                     $(this).val((Number(2)).toFixed(2));
                }
                else {
                    $(this).val((Number(0)).toFixed(2));
                }

            });
             $(".modelInput").eq(0).focus();
              demo.curveUpdation();
            //that.showTable($.inArray(that._activityYear, yearCalculation));
           
           
        }
    });
    $(".tableModelInput").off("focusin").on("focusin", function () {
        $(this).val((Number($(this).val())).toFixed(2));
        that.inputFocusEventBind($(this), ind);
        demo.curveUpdation();
    });
    $(".tableModelInput").off("focusout").on("focusout", function () {
        $(this).val((Number($(this).val())).toFixed(2));
        that.inputFocusEventBind($(this), ind);
        demo.curveUpdation();
    });
    $(".tableModelInput").off("keypress").on("keypress", function (e) {
        if (e.keyCode === 13)
        {
            $(this).val((Number($(this).val())).toFixed(2));
            that.inputFocusEventBind($(this), ind);
            demo.curveUpdation();
        }
    });
    that.updateTable(1);

};
macroModels.prototype.inputFocusEventBind = function (obj, ind) {
	var minRange=Number(obj.siblings(".minRange").text());
	var maxRange=Number(obj.siblings(".maxRange").text());
	if($.trim(obj.siblings(".minRange").text())===""){
		minRange=0;
		maxRange=2;
	}
    if (obj.val() < minRange) {
        obj.val((minRange).toFixed(2));
    }
    else if (obj.val() > maxRange) {
        obj.val((maxRange).toFixed(2));
    }
    else {
        obj.val((Number(obj.val())).toFixed(2));
   }
	//Old Code error setting values to 0.00 in 2000 column
	/*if (obj.val() < Number(obj.siblings(".minRange").text())) {
        obj.val((Number(obj.siblings(".minRange").text())).toFixed(2));
    }
    else if (obj.val() > Number(obj.siblings(".maxRange").text())) {
        obj.val((Number(obj.siblings(".maxRange").text())).toFixed(2));
    }
    else {
        obj.val((Number(obj.val())).toFixed(2));
   }*/
    var ind = $.inArray(this._activityYear, yearCalculation)
      _previousYear[Number(ind-1)]=({
                'val1': Number($(".modelInput").eq(0).val()),
                'val2': Number($(".modelInput").eq(1).val()),
                'val3': Number($(".modelInput").eq(2).val()),
                'val4':  Number($(".modelInput").eq(3).val())
            });
    this.updateTable($.inArray(this._activityYear, yearCalculation));
};
macroModels.prototype.updateTable = function (ind) {
    // console.log(ind-1)
    for (var i = (ind - 1); i < $('.demandrate').length; i++) {
        if (i > (ind - 1)) {

            if (i < 2) {
                $(".demandrate").eq(i).html(Number($(".demandrate input").eq(i - 1).val()).toFixed(2));
                $(".naturalrate").eq(i).html(Number($(".naturalrate input").eq(i - 1).val()).toFixed(2));
                $(".inflationrate").eq(i).html(Number($(".inflationrate input").eq(i - 1).val()).toFixed(2));
                $(".monetarypolicyrate").eq(i).html(Number($(".monetarypolicyrate input").eq(i - 1).val()).toFixed(2));
                $(".monetarypolicyrule").eq(i).html(Number($(".monetarypolicyrule input").eq(i - 1).val()).toFixed(2));

                $(".ParameterA").eq(i - 1).html(Number((Number($(".demandrate input").eq(i - 1).val()) * Number($(".monetarypolicyrate input").eq(i - 1).val())) / (1 + Number($(".demandrate input").eq(i - 1).val()) * Number($(".monetarypolicyrule input").eq(i - 1).val()))).toFixed(2));
                $(".ParameterB").eq(i - 1).html(Number(1 / (1 + Number($(".demandrate input").eq(i - 1).val()) * Number($(".monetarypolicyrule input").eq(i - 1).val()))).toFixed(2));


            }
            else {

                $(".demandrate").eq(i).html(Number($(".demandrate").eq(i - 1).text()).toFixed(2));
                $(".naturalrate").eq(i).html(Number($(".naturalrate").eq(i - 1).text()).toFixed(2));
                $(".inflationrate").eq(i).html(Number($(".inflationrate").eq(i - 1).text()).toFixed(2));
                $(".monetarypolicyrate").eq(i).html(Number($(".monetarypolicyrate").eq(i - 1).text()).toFixed(2));
                $(".monetarypolicyrule").eq(i).html(Number($(".monetarypolicyrule").eq(i - 1).text()).toFixed(2));
                $(".ParameterA").eq(i - 1).html(Number((Number($(".demandrate").eq(i - 1).text()) * Number($(".monetarypolicyrate").eq(i - 1).text())) / (1 + Number($(".demandrate").eq(i - 1).text()) * Number($(".monetarypolicyrule").eq(i - 1).text()))).toFixed(2));
                $(".ParameterB").eq(i - 1).html(Number(1 / (1 + Number($(".demandrate").eq(i - 1).text()) * Number($(".monetarypolicyrule").eq(i - 1).text()))).toFixed(2));



            }
        }


    }

    for (var i = (ind - 1); i < $('.output').length; i++) {
        if (i > 0)
        {
            $('.predVarCol').eq(i).html(Number($(".inflaton").eq(i - 1).text()).toFixed(2));

            var paramA = Number((Number($(".demandrate").eq(i).text()) * Number($(".monetarypolicyrate").eq(i).text())) / (1 + Number($(".demandrate").eq(i).text()) * Number($(".monetarypolicyrule").eq(i).text())));

            var paramB = Number(1 / (1 + Number($(".demandrate").eq(i).text()) * Number($(".monetarypolicyrule").eq(i).text())));

            var output = Number($(".modelInput").eq(0).val()) + (-paramA * Number($('.predVarCol').eq(i).text()) - paramA * Number($(".modelInput").eq(3).val()) + paramA * Number($(".modelInput").eq(1).val()) + paramB * Number($(".modelInput").eq(2).val())) / (1 + paramA * Number($(".inflationrate").eq(i).text()));
            $(".output").eq(i).html(Number(output).toFixed(2));

            var inflation = Number($('.predVarCol').eq(i).text()) + Number($(".inflationrate").eq(i).text()) * (Number(output) - Number($(".modelInput").eq(0).val())) + Number($(".modelInput").eq(3).val());
            $(".inflaton").eq(i).html(Number(inflation).toFixed(2));

            $(".nominalinterestrate").eq(i).html(Number(Number(inflation) + Number($(".naturalrate").eq(i).text()) + Number($(".monetarypolicyrate").eq(i).text()) * (Number(inflation) - Number($(".modelInput").eq(1).val())) + Number($(".monetarypolicyrule").eq(i).text()) * (Number(output) - Number($(".modelInput").eq(0).val()))).toFixed(2));

            $(".expectedinflation").eq(i).html(Number($(".inflaton").eq(i).html()).toFixed(2));
            $(".realinterestrate").eq(i).html((Number($(".nominalinterestrate").eq(i).html()) - Number($(".expectedinflation").eq(i).html())).toFixed(2));
        }
        else
        {
            var paramA = Number((Number($(".demandrate input").eq(i).val()) * Number($(".monetarypolicyrate input").eq(i).val())) / (1 + Number($(".demandrate input").eq(i).val()) * Number($(".monetarypolicyrule input").eq(i).val())));

            var paramB = Number(1 / (1 + Number($(".demandrate input").eq(i).val()) * Number($(".monetarypolicyrule input").eq(i).val())));

            var output = Number($(".modelInput").eq(0).val()) + (-paramA * Number($('.predVarCol').eq(i).text()) - paramA * Number($(".modelInput").eq(3).val()) + paramA * Number($(".modelInput").eq(1).val()) + paramB * Number($(".modelInput").eq(2).val())) / (1 + paramA * Number($(".inflationrate input").eq(i).val()));
            $(".output").eq(i).html(Number(output).toFixed(2));

            var infaltion = Number(Number($('.predVarCol').eq(i).text()) + Number($(".inflationrate input").eq(i).val()) * (Number(output) - Number($(".modelInput").eq(0).val())) + Number($(".modelInput").eq(3).val()));

            $(".inflaton").eq(i).html(Number(infaltion).toFixed(2));

            $(".nominalinterestrate").eq(i).html(Number(infaltion + Number($(".naturalrate input").eq(i).val()) + Number($(".monetarypolicyrate input").eq(i).val()) * (infaltion - Number($(".modelInput").eq(1).val())) + Number($(".monetarypolicyrule input").eq(i).val()) * (Number(output) - Number($(".modelInput").eq(0).val()))).toFixed(2));

            $(".expectedinflation").eq(i).html(Number($(".inflaton").eq(i).html()).toFixed(2));
            $(".realinterestrate").eq(i).html((Number($(".nominalinterestrate").eq(i).html()) - Number($(".expectedinflation").eq(i).html())).toFixed(2));
        }
    }


};


macroModels.prototype.getType = function (input) {
    var m = (/[\d]+(\.[\d]+)?/).exec(input);
    if (m) {
        // Check if there is a decimal place
        if (m[1]) {
            return 'float';
        }
        else {
            return 'int';
        }
    }
    return 'string';
};
$(function () {
    Model = new macroModels();
    Model.LoadXML();
    demo.Init();
});

var Model;