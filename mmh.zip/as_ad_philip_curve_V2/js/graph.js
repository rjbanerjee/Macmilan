var demo = {};
var asadboard, diagram01, diagram02, diagram03, diagram04, diagram05, diagram06, diagram07, diagram08;
var diagram01arr = {"val1": [0], "val2": [4]}, diagram02arr = {"val1": [0], "val2": [4]}, diagram03arr = {"val1": [0], "val2": [4]}, diagram04arr = {"val1": [0], "val2": [4]}, diagram05arr = {"val1": [0], "val2": [4]}, diagram06arr = {"val1": [0], "val2": [4]}, diagram07arr = {"val1": [0], "val2": [4]}, diagram08arr = {"val1": [0], "val2": [4]};
var unemploymentCurve = {"val1": [0, 1], "val2": [5, 5]};

//X Axis Value Conversion
var xASADValConvert = function (x) {
    var min = 98;
    var max = 102;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 4;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//Y Axis Value Conversion
var yASADValConvert = function (y) {
    var min = 1.5;
    var max = 2.9;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 14;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};
//Y Axis Value Conversion
var diagramYValConvert = function (arr, y) {
    var min = arr[0];
    var max = arr[1];
    var diff = max - min;
    var minSlide = arr[2];
    var maxSlide = arr[3];

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};


var asCurveFirstYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
    var data = ((yearCalc - 2) === 0) ? Number($(".inflationrate input").eq(yearCalc - 2).val()) : Number($(".inflationrate").eq(yearCalc - 2).text());
   // console.log(Number($(".predVarCol").eq(yearCalc - 2).text())+ "+"+ data + "+"+  (num + "+"+  _previousYear[yearCalc - 2].val1) + "+"+  _previousYear[yearCalc - 2].val4)
    return Number($(".predVarCol").eq(yearCalc - 2).text()) + data * (num - _previousYear[yearCalc - 2].val1) + _previousYear[yearCalc - 2].val4;

};

var asCurveCurrentYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
    var val1 =  Number($(".modelInput").eq(0).val())//((_previousYear[yearCalc - 1] !== undefined) ? _previousYear[yearCalc - 1].val1 : Number($(".modelInput").eq(0).val()));
    var val4 =  Number($(".modelInput").eq(3).val())//((_previousYear[yearCalc - 1] !== undefined) ? _previousYear[yearCalc - 1].val4 : Number($(".modelInput").eq(3).val()));
   // console.log(Number($(".predVarCol").eq(yearCalc - 1).text())+" +"+ Number($(".inflationrate").eq(yearCalc - 1).text())+ "*"+ (num + "*"+ val1) + "*"+ val4)
    return Number($(".predVarCol").eq(yearCalc - 1).text()) + Number($(".inflationrate").eq(yearCalc - 1).text()) * (num - val1) + val4;
};


var adCurveFirstYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);

    return _previousYear[yearCalc - 2].val1 - Number($(".ParameterA").eq(yearCalc - 2).text()) * (num - _previousYear[yearCalc - 2].val2) + Number($(".ParameterB").eq(yearCalc - 2).text()) * _previousYear[yearCalc - 2].val3;
};

var adCurveCurrentYearEquation = function (num) {
    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
    var val1 = ((_previousYear[yearCalc - 1] !== undefined) ? _previousYear[yearCalc - 1].val1 : Number($(".modelInput").eq(0).val()));
    var val2 = ((_previousYear[yearCalc - 1] !== undefined) ? _previousYear[yearCalc - 1].val2 : Number($(".modelInput").eq(1).val()));
    var val3 = ((_previousYear[yearCalc - 1] !== undefined) ? _previousYear[yearCalc - 1].val3 : Number($(".modelInput").eq(2).val()));
    return val1 - Number($(".ParameterA").eq(yearCalc - 1).text()) * (num - val2) + Number($(".ParameterB").eq(yearCalc - 1).text()) * val3;
};

//var adCurveCurrentYearEquation = function (num) {
//    var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
//
//    return Math.round(Number((Number($(".tableView tr").eq(6).find(".output").eq(yearCalc - 2).text()) * (1 + Number($(".tableView tr").eq(3).find(".nominalgdp").eq(yearCalc - 1).text()) / 100) - 470 / 0.91 * (num - Number($(".tableView tr").eq(1).find(".expectedinflation").eq(yearCalc - 1).text()))).toFixed(2)));
//};


demo.Init = function () {
    /*AS-AD Borad*/
    asadboard = JXG.JSXGraph.initBoard('asadBox', {
        axis: false,
        boundingbox: [0, 14, 4, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    asadboard.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    asadboard.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    asadboard.create('line', [[xASADValConvert(95), function () {
                return  yASADValConvert(asCurveFirstYearEquation(95));
            }], [xASADValConvert(105),
            function () {
                return yASADValConvert(asCurveFirstYearEquation(105));
            }]], {
        strokeWidth: 1.5,
        strokeColor: 'blue',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
            //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AS'" + (Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2, 2);
        },
        withLabel: true,
        label: {offset: [300, 200], color: 'blue', cssClass: 'myBold'
        }
    });
    asadboard.create('line', [[function () {
                return  xASADValConvert(adCurveFirstYearEquation(0.5));
            }, yASADValConvert(0.5)], [function () {
                return  xASADValConvert(adCurveFirstYearEquation(4.5));
            }, yASADValConvert(4.5)]], {
        strokeWidth: 1.5,
        strokeColor: '#95F2D8',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
            //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AD'" + (Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2, 2);
        },
        withLabel: true,
        label: {offset: [0, -370], highlight: false,color: '#008000', cssClass: 'myBold'
        }
    });

    asadboard.create('line', [[xASADValConvert(95), function () {
                return  yASADValConvert(asCurveCurrentYearEquation(95))
            }], [xASADValConvert(105), function () {
                return  yASADValConvert(asCurveCurrentYearEquation(105))
            }]], {
        strokeWidth: 1.5,
        strokeColor: '#DD3232',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
            //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AS'" + (Number($(".rangeYear").eq(0).text())).toString().substr(2, 2);
        },
        withLabel: true,
        label: {offset: [300, 175],highlight: false, color: '#DD3232', cssClass: 'myBold'
        }
    });

    asadboard.create('line', [[function () {
                return  xASADValConvert(adCurveCurrentYearEquation(0.5))
            }, yASADValConvert(0.5)], [function () {
                return  xASADValConvert(adCurveCurrentYearEquation(4.5))
            }
            , yASADValConvert(4.5)]], {
        strokeWidth: 1.5,
        strokeColor: '#4B738F',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
            //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "AD'" + (Number($(".rangeYear").eq(0).text())).toString().substr(2, 2);
        },
        withLabel: true,
        label: {offset: [0, -350], highlight: false,color: '#4B738F', cssClass: 'myBold'
        }
    });

    asadboard.create('line', [[function () {
                var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
                return xASADValConvert(_previousYear[yearCalc - 2].val1)

            }, yASADValConvert(0.5)], [function () {
                var yearCalc = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation);
                return xASADValConvert(_previousYear[yearCalc - 2].val1)
            }, yASADValConvert(4.5)]], {
        strokeWidth: 1.5,
        strokeColor: 'green',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: function () {
            //   console.log("as'"+(Number($(".rangeYear").eq(0).text()) - 1).toString().substr(2,2))
            return "Ῡ";
        },
        withLabel: true,
        label: {offset: [10, 250],highlight: false, color: 'green', cssClass: 'myBold'
        }
    });

    /*Diagrams Borad*/

    diagram01 = JXG.JSXGraph.initBoard('diagram01', {
        axis: false,
        boundingbox: [0, 8, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    diagram01.create('text', [-1.3, 25, "20.00"]);
    diagram01.create('text', [-0.7, 12, "%"]);
    diagram01.create('text', [-1.2, 2, "-5.00"]);

    diagram01.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram01.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram01.create('curve', [diagram01arr.val1, diagram01arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});

    diagram02 = JXG.JSXGraph.initBoard('diagram02', {
        axis: false,
        boundingbox: [0, 8, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    diagram02.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram02.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram02.create('curve', [diagram02arr.val1, diagram02arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});

    diagram03 = JXG.JSXGraph.initBoard('diagram03', {
        axis: false,
        boundingbox: [0, 6, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    diagram03.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram03.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram03.create('curve', [diagram03arr.val1, diagram03arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});

    diagram04 = JXG.JSXGraph.initBoard('diagram04', {
        axis: false,
        boundingbox: [0, 8, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    diagram04.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram04.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram04.create('curve', [diagram04arr.val1, diagram04arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});
    diagram05 = JXG.JSXGraph.initBoard('diagram05', {
        axis: false,
        boundingbox: [0, 8, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });

    diagram05.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram05.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram05.create('curve', [diagram05arr.val1, diagram05arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});

    diagram06 = JXG.JSXGraph.initBoard('diagram06', {
        axis: false,
        boundingbox: [0, 6, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    diagram06.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram06.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram06.create('curve', [diagram06arr.val1, diagram06arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});
    diagram07 = JXG.JSXGraph.initBoard('diagram07', {
        axis: false,
        boundingbox: [0, 10, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    diagram07.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram07.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram07.create('curve', [diagram07arr.val1, diagram07arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});

    diagram08 = JXG.JSXGraph.initBoard('diagram08', {
        axis: false,
        boundingbox: [0, 6, 16, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    diagram08.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    diagram08.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 1.5,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    diagram08.create('curve', [diagram08arr.val1, diagram08arr.val2],
            {strokeColor: '#D90000',
                name: "",
                highlight: false,
                strokeWidth: 1.5,
                fixed: true,
                withLabel: true,
                label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [-180, 0] // (in pixels)
                }});
    // this.curveUpdation();
};
demo.curveUpdation = function () {
    var totalNumberYears = $.inArray(Number($(".rangeYear").eq(0).text()), yearCalculation)
    for (var i = 0; i < totalNumberYears - 1; i++) {
        diagram01arr.val1[i] = i;
        diagram01arr.val2[i] = diagramYValConvert([-2, 2, 0, 8], _previousYear[i].val4);
        diagram02arr.val1[i] = i;
        diagram02arr.val2[i] = diagramYValConvert([-2, 2, 0, 8], _previousYear[i].val3);
        diagram03arr.val1[i] = i;
        diagram03arr.val2[i] = diagramYValConvert([0, 3, 0, 6], _previousYear[i].val2);
        diagram04arr.val1[i] = i;
        diagram04arr.val2[i] = diagramYValConvert([98, 102, 0, 8], _previousYear[i].val1);
        diagram05arr.val1[i] = i;
        diagram05arr.val2[i] = diagramYValConvert([98, 102, 0, 8], Number($(".output").eq(i).html()));
        diagram06arr.val1[i] = i;
        diagram06arr.val2[i] = diagramYValConvert([0, 3, 0, 6], Number($(".inflaton").eq(i).html()));
        diagram07arr.val1[i] = i;
        diagram07arr.val2[i] = diagramYValConvert([1, 3, 0, 10], Number($(".realinterestrate").eq(i).html()));
        diagram08arr.val1[i] = i;
        diagram08arr.val2[i] = diagramYValConvert([3, 6, 0, 6], Number($(".nominalinterestrate").eq(i).html()));
    }
    this.graphManupulation();
}
demo.graphManupulation = function () {
    asadboard.fullUpdate();
    diagram01.fullUpdate();
    diagram02.fullUpdate();
    diagram03.fullUpdate();
    diagram04.fullUpdate();
    diagram05.fullUpdate();
    diagram06.fullUpdate();
    diagram07.fullUpdate();
    diagram08.fullUpdate();
};
  