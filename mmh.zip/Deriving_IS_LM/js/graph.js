var demo = {};
var board;
var board1;
var board2;
var board3;
var IData;
var SData;

var userData = {};
userData.govtSpen = 1000; // 650 to 850
userData.taxes = 1000; //7.50 to 8.50
userData.moneySupply = 750; // 650 to 850
userData.priceLevel = 0; //7.50 to 8.50
userData.isMargin = 0.60; //-150 to 150
userData.isInterest = -3 //-150 to 150
userData.lmMargin = -0.50; //-150 to 150
userData.lmInterest = 1; // -440 to -320

userData.xList = [50, 38.75, 27.5, 16.25, 5];
userData.xSecondList = [50, 38.75, 27.5, 16.25, 5];

userData.siY1 = 5703;
userData.siI1 = 1031;
userData.siY2 = 4297;
userData.siI2 = 469;
userData.lmr1 = 6.40;
userData.lmr2 = 9.6;

userData.isBaser1 = 5703;
userData.isBaser2 = 1031;
userData.isBaser3 = 4297;
userData.isBaser4 = 469;

userData.lmBaser1 = 6.40;
userData.lmBaser2 = 9.60;
var xValConvertMoneyMarket = function (x) {
    var min = 500;
    var max = 1000;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 5;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};
//Y Axis Value Conversion
var yValConvert = function (y) {
    var min = 4;
    var max = 12;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 8;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};

//Y Axis Value Conversion
var ykeynasianValConvert = function (y) {
    var min = 0;
    var max = 6500;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 65;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
   // console.log(yLinePoint)
    return yLinePoint;
};


var xValConvertLmDiagram = function (x) {
    var min = 0;
    var max = 6500;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 65;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//X Axis Value Rev Conversion
var xValRevConvert = function (x) {
    var min = 0;
    var max = 6500;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 65;

    var xLinePoint = ((diff / maxSlide) * x);
    return min + xLinePoint;
};

var xLmValConvertLmDiagram = function (x) {
    var min = 3500;
    var max = 6500;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 6;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//X Axis Value Rev Conversion
var xLmValRevConvert = function (x) {
    var min = 3500;
    var max = 6500;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 6;

    var xLinePoint = ((diff / maxSlide) * x);
    return min + xLinePoint;
};

//Y Axis Value Rev Conversion
var ySecondValRevConvert = function (y) {
    var min = 6;
    var max = 10;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 4;

    var yLinePoint = ((diff / maxSlide) * y);
    return min + yLinePoint;
};
var getIsXfromY = function(x){
    //Graph scenario value;
   return Number((100- userData.isMargin*userData.taxes+(((-3/userData.isInterest-1)/4+1)*4200-450*ySecondValRevConvert(x))+userData.govtSpen)/(1- userData.isMargin));
}
var getIsSecondXfromY = function(x){
    //Graph scenario value;
   return Number((100- userData.isMargin*1000+(((-3/userData.isInterest-1)/4+1)*4200-450*ySecondValRevConvert(x))+1000)/(1- userData.isMargin));
}

var generateIsXRange = function(){
    for(var i=0; i<=4; i++){
       userData.xList[i] = xValConvertLmDiagram(getIsXfromY(i));
       userData.xSecondList[i]= xValConvertLmDiagram(getIsSecondXfromY(i));
    }
    board1.fullUpdate();
};

demo.Init = function () {

    board = JXG.JSXGraph.initBoard('box', {
        axis: false,
        boundingbox: [0, 65, 65, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });


    var xaxis = board.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var yaxis = board.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

 
  var secondLineR7 = board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
            return ykeynasianValConvert(100+userData.isMargin*(x-userData.taxes)+((-3/userData.isInterest-1)/4+1)*4200-450*7+userData.govtSpen);
       }, xValConvertLmDiagram(0), xValConvertLmDiagram(6500)], {
        strokeWidth: 1.5,
        strokeColor: '#C00000',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "E1'(r=7%)",
        withLabel: true,
         label: {offset: [0, 10],cssClass:'italics'}
    });
    
    var redLineR7 = board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
            return ykeynasianValConvert(100+userData.isMargin*(x-1000)+((-3/userData.isInterest-1)/4+1)*4200-450*7+1000);
       }, xValConvertLmDiagram(0), xValConvertLmDiagram(6500)], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "E1 (r=7%)",
        withLabel: true,
         label: {offset: [0, 10],cssClass:'italics'}
    });
    
    
     var secondLineR9 = board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
            return ykeynasianValConvert(100+userData.isMargin*(x-userData.taxes)+((-3/userData.isInterest-1)/4+1)*4200-450*9+userData.govtSpen);
       }, xValConvertLmDiagram(0), xValConvertLmDiagram(6500)], {
        strokeWidth: 1.5,
        strokeColor: '#C00000',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "E2'(r=9%)",
        withLabel: true,
         label: {offset: [0, 20],cssClass:'italics'}
    });
    
    var redLineR9 = board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
            return ykeynasianValConvert(100+userData.isMargin*(x-1000)+((-3/userData.isInterest-1)/4+1)*4200-450*9+1000);
       }, xValConvertLmDiagram(0), xValConvertLmDiagram(6500)], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "E2 (r=9%)",
        withLabel: true,
        label: {offset: [0, 20],cssClass:'italics'}
    });
     
 
 

    var line5 = board.create('line', [[0, 0], [65, 65]], {
        straightFirst: false,
        straightLast: false,
        name: 'E=Y',
        withLabel: true,
        strokeWidth: 2,
        fixed: true,
        highlight: false,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [5, 0] // (in pixels)
            ,cssClass:'italics'
        },
        strokeColor: 'blue'
    });





    /***********************Secong Graph********************************/
    board1 = JXG.JSXGraph.initBoard('box1', {
        axis: false,
        boundingbox: [0, 4, 65, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });

    var xaxis1 = board1.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var yaxis1 = board1.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, 0] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

      var line6 = board1.create('line', [[0, 3], [65, 3]], {
        straightFirst: false,
        straightLast: false,
        name: '9',
        withLabel: true,
        strokeWidth: 2,
        fixed: true,
        highlight: false,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-280, 5], // (in pixels)
            cssClass:'italics'
        },
        strokeColor: 'blue'
    });
    var line7 = board1.create('line',  [[0, 1], [65, 1]], {
        straightFirst: false,
        straightLast: false,
        name: '7',
        withLabel: true,
        fixed: true,
        highlight: false,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-240, 10], // (in pixels)
            cssClass:'italics'
        },
        strokeWidth: 2,
        strokeColor: 'blue'
    });
    var y = [0,1,2,3,4];
  var graph = board1.create('curve', [userData.xList,y], {
        strokeWidth: 1.5,
         strokeColor: '#C00000',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "IS'",
        withLabel: true,
        label: {offset: [80, -150],cssClass:'italics'}
    });
    var graph = board1.create('curve', [userData.xSecondList,y], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "IS",
        withLabel: true,
        label: {offset: [80, -150],cssClass:'italics'}
    });

    /********************************************************************************/
    /************************************Graph 02*************************************/
    /********************************************************************************/

    board2 = JXG.JSXGraph.initBoard('box2', {
        axis: false,
        boundingbox: [-1, 8, 5, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });

    var xaxis2 = board2.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        straightFirst: false,
        straightLast: true,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var yaxis2 = board2.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var text1 = board2.create('text', [-.7, 8, "12.00"]);
    var text2 = board2.create('text', [-.5, 3.5, "r"],{cssClass:'italics'});
    var text3 = board2.create('text', [-.7, 0.5, "4.00"]);

    var line1_g2 = board2.create('line', [[3.7, 0], [0, 7.2]], {
        straightFirst: false,
        straightLast: false,
        name: 'Y=4,500',
        withLabel: true,
        strokeWidth: 2,
        fixed: true,
        highlight: false,
        label: {
            position: 'top', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, -50] // (in pixels)
            ,cssClass:'italics'
        },
        strokeColor: 'blue'
    });

    var line2_g2 = board2.create('line', [[5.5, 0], [0, 10.4]], {
        straightFirst: false,
        straightLast: false,
        withLabel: true,
        strokeWidth: 2,
        highlight: false,
        fixed: true,
        name: 'Y=5,500',
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [10, 10] // (in pixels)
            ,cssClass:'italics'
        },
        strokeColor: 'blue'
    });
    var line3_g2 = board2.create('line', [[function () {
                return ((xValConvertMoneyMarket((userData.moneySupply / userData.priceLevel))) < 0) ? -2 : xValConvertMoneyMarket((userData.moneySupply / userData.priceLevel));
            }, 0], [function () {
                return ((xValConvertMoneyMarket((userData.moneySupply / userData.priceLevel))) < 0) ? -2 : xValConvertMoneyMarket((userData.moneySupply / userData.priceLevel));
            }, 8]], {
        straightFirst: false,
        straightLast: false,
        name: "M/P'",
        withLabel: true,
        strokeWidth: 2,
        fixed: true,
        highlight: false,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, 0] // (in pixels)
            ,cssClass:'italics'
        },
        strokeColor: '#C00000'
    });

    var line3_g2 = board2.create('line', [[2.5, 0], [2.5, 8]], {
        straightFirst: false,
        straightLast: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        highlight: false,
        fixed: true,
        name: "M/P",
        withLabel: true,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, 0]  // (in pixels)
            ,cssClass:'italics'
        },
    });

    /*-----------------------------------------------------------------------------------*/
    board3 = JXG.JSXGraph.initBoard('box3', {
        axis: false,
        boundingbox: [-1, 8, 6, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });

    var xaxis2 = board3.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        straightFirst: false,
        straightLast: true,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var yaxis2 = board3.create('axis', [[0, 0], [0, 1]], {
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#484848',
        strokeWidth: '2',
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var text1 = board3.create('text', [-.9, 8, "12.00"]);
    var text2 = board3.create('text', [-.5, 3.5, "r"],{cssClass:'italics'});
    var text3 = board3.create('text', [-.9, 0.5, "4.00"]);

    var line4_g2 = board3.create('line', [[function () {
                return  xLmValConvertLmDiagram(4500);
            }, 0], [function () {
                return  xLmValConvertLmDiagram(4500);
            }, 8]], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 2,
        fixed: true,
        highlight: false,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-35, -180] // (in pixels)
            ,cssClass:'italics'
        },
        strokeColor: 'blue'
    });

    var line5_g2 = board3.create('line', [[function () {
                return  xLmValConvertLmDiagram(5500);
            }, 0], [function () {
                return  xLmValConvertLmDiagram(5500);
            }, 8]], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 2,
        highlight: false,
        fixed: true,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-35, -180] // (in pixels)
            ,cssClass:'italics'
        },
        strokeColor: 'blue'
    });
    var line6_g2 = board3.create('functiongraph', [function (x) {
            x = xLmValRevConvert(x);
           return yValConvert(userData.lmr1 + (userData.lmr2 - userData.lmr1) / 1000 * (x - 4500));
        }, xLmValConvertLmDiagram(3500), xLmValConvertLmDiagram(6500)], {
        strokeWidth: 1.5,
        strokeColor: '#C00000',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "LM'",
        withLabel: true,
        label: {offset: [0, 50],cssClass:'italics'}
    });

    var line6_g2 = board3.create('functiongraph', [function (x) {
            x = xLmValRevConvert(x);
            return yValConvert(userData.lmBaser1 + (userData.lmBaser2 - userData.lmBaser1) / 1000 * (x - 4500));
        }, xLmValConvertLmDiagram(3500), xLmValConvertLmDiagram(6500)], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "LM",
        withLabel: true,
        label: {offset: [0, 50],cssClass:'italics'}
    });

    this.sliderChange();
};

demo.sliderChange = function () {

    $("input[id^='ex']").each(function () {
        $(this).initiateSlider();
    });
};

$.fn.initiateSlider = function () {
    var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
           
            var vElmValue = (parseInt(value) === value) ? value : value.toFixed(2);
             vElmValue = (demo.getType(oThisElm.attr("data-slider-value")) === "float")?
            Number(value).toFixed(2):vElmValue;
             oThisElm.parent().parent().find(".rhinput").val(vElmValue);
            return 'Current value: ' + value;
        }
    });
    $("input[id^='ex']").slider().off().on('slideStop', function (ev, k) {
         demo.fieldUpdation();
         if($(this).hasClass("baseChange")){demo.seperateFieldUpdation();}
        demo.graphManupulation();
         
    });
};
demo.fieldUpdation = function () {
    //range slider variable update
    userData.govtSpen = Number($("#Graph01 .block01 .rholder .rhinput")[0].value); // 650 to 850
    userData.taxes = Number($("#Graph01 .block01 .rholder .rhinput")[2].value); //7.50 to 8.50
    userData.moneySupply = Number($("#Graph02 .block01 .rholder .rhinput")[0].value); // 650 to 850
    userData.priceLevel = Number($("#Graph02 .block01 .rholder .rhinput")[2].value); //7.50 to 8.50
    userData.isMargin = Number($("#Graph01 .intro .rholder .rhinput")[0].value); //-150 to 150
    userData.isInterest = Number($("#Graph01 .intro .rholder .rhinput")[2].value); //-150 to 150
    userData.lmMargin = Number($("#Graph02 .intro1 .rholder .rhinput")[0].value); //-150 to 150
    userData.lmInterest = Number($("#Graph02 .intro1 .rholder .rhinput")[2].value); // -440 to -320

//Input boxes variable update
    userData.siI1 = Number((((-3 / userData.isInterest - 1) / 4 + 1) * 4200 - 450 * 7).toFixed(0));
    userData.siY1 = Number(((100 - userData.isMargin * userData.taxes + userData.siI1 + userData.govtSpen) / (1 - userData.isMargin)).toFixed(0));
    userData.siI2 = Number((((-3 / userData.isInterest - 1) / 4 + 1) * 4200 - 450 * 9).toFixed(0));
    userData.siY2 = Number(((100 - userData.isMargin * userData.taxes + userData.siI2 + userData.govtSpen) / (1 - userData.isMargin)).toFixed(0));

    userData.lmr1 = Number(((4500 - (1 + userData.lmMargin) * 5000 - ((userData.moneySupply / userData.priceLevel) - 750) * 6.66666666666666) / (-625 * userData.lmMargin) - (userData.lmInterest - 1) * (0.8 / -userData.lmMargin)).toFixed(2));
    userData.lmr2 = Number(((5500 - (1 + userData.lmMargin) * 5000 - ((userData.moneySupply / userData.priceLevel) - 750) * 6.66666666666666) / (-625 * userData.lmMargin) + (userData.lmInterest - 1) * (0.8 / -userData.lmMargin)).toFixed(2));
   //update the input boxes with update board
    demo.graphManupulation();
};
demo.seperateFieldUpdation = function () {
    
        userData.isBaser2 = Number((((-3 / userData.isInterest - 1) / 4 + 1) * 4200 - 450 * 7).toFixed(0));
    userData.isBaser1 = Number(((100 - userData.isMargin * 1000 + userData.isBaser2 + 1000) / (1 - userData.isMargin)).toFixed(0));

    userData.isBaser4 = Number((((-3 / userData.isInterest - 1) / 4 + 1) * 4200 - 450 * 9).toFixed(0));
    userData.isBaser3 = Number(((100 - userData.isMargin * 1000 + userData.isBaser4 + 1000) / (1 - userData.isMargin)).toFixed(0));
    
    
    userData.lmBaser1 = Number(((4500 - (1 + userData.lmMargin) * 5000 - ((750 / 1) - 750) * 6.66666666666666) / (-625 * userData.lmMargin) - (userData.lmInterest - 1) * (0.8 / -userData.lmMargin)).toFixed(2));
    userData.lmBaser2 = Number(((5500 - (1 + userData.lmMargin) * 5000 - ((750 / 1) - 750) * 6.66666666666666) / (-625 * userData.lmMargin) + (userData.lmInterest - 1) * (0.8 / -userData.lmMargin)).toFixed(2));
    demo.graphManupulation();
};

demo.graphManupulation = function () {
    $("#Graph01 .I").eq(0).val(userData.siI1);
    $("#Graph01 .Y").eq(0).val(userData.siY1);
    $("#Graph01 .I").eq(1).val(userData.siI2);
    $("#Graph01 .Y").eq(1).val(userData.siY2);
    $("#Graph02 .r").eq(0).val(userData.lmr1);
    $("#Graph02 .r").eq(1).val(userData.lmr2);
    $("#Graph01 .baseline").eq(0).html(userData.isBaser1);
    $("#Graph01 .baseline").eq(1).html(userData.isBaser2);
    $("#Graph01 .baseline").eq(2).html(userData.isBaser3);
    $("#Graph01 .baseline").eq(3).html(userData.isBaser4);
    $("#Graph02 .baseline").eq(0).html((userData.lmBaser1).toFixed(2));
    $("#Graph02 .baseline").eq(1).html((userData.lmBaser2).toFixed(2));

    generateIsXRange();
    
    board.fullUpdate();
    board1.fullUpdate();
    board2.fullUpdate();
    board3.fullUpdate();
};
demo.getType=function(input) {
    var m = (/[\d]+(\.[\d]+)?/).exec(input);
    if (m) {
       // Check if there is a decimal place
       if (m[1]) { return 'float'; }
       else { return 'int'; }          
    }
    return 'string';
}