/**
 * Main _Contructor Function of this Application.
 */
function macroModels() {
    this._xmlFileName = "Activity.xml";
    this._xmlFilePath = "./xml/";
    this._xmlObject = null;
    this._activityTitle = null;
}

/**
 * Function Loads the Macromodel Activity XML from the configured parameters in _Constructor.
 * The Function Store the XML Object in the Defined Variable in _Constructor.
 */
macroModels.prototype.LoadXML = function () {
    //Loading XML File.
    this._xmlObject = loadXMLDoc(this._xmlFilePath + this._xmlFileName);
    //Parsing XML String.
    this._xmlObject = parseXMLString(this._xmlObject);
    //The Main DOM is been added in Object.
    this._xmlObject = this._xmlObject.getElementsByTagName("activity")[0];
    this.GenerateHTML();
    this.controlTab();
}

/**
 * [[Description]]
 */


macroModels.prototype.GenerateHTML = function () {
    // stri  
    //Title Name
    this._activityTitle = this._xmlObject.getElementsByTagName("heading")[0].childNodes[0].nodeValue;
    $("title").html(this._activityTitle);
    $(".modelTitle a").html(this._activityTitle);
    $(".questionHolder p").html(this._xmlObject.getElementsByTagName("question")[0].childNodes[0].nodeValue);
    var _activityTabs = this._xmlObject.getElementsByTagName("section");
    var _activityTabsCount = this._xmlObject.getElementsByTagName("section").length;

    for (i = 0; i < _activityTabsCount; i++) {
        $(".nav li:eq(" + i + ") a").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "content") {
           // $(".tab-pane :eq(" + i + ") h3").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

            $(".tab-pane :eq(" + i + ") p").html(this._xmlObject.getElementsByTagName("section")[0].childNodes[1].textContent);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContent") {
            //alert(this._xmlObject.getElementsByTagName("rangeOptions"))
//                    console.log(this._xmlObject.getElementsByTagName("rangeOptions").childNodes)
//                      var _activityQestionRangeCount = this._xmlObject.getElementsByTagName("rangeOptions");
//                      alert(_activityQestionRangeCount[0].getElementsByTagName("options").length); 
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[1].childNodes[1].textContent);
            var xmlObj = this._xmlObject;
            var sliderObjCounter = 0;
            var quesparameter = '';
            var exogenousrangeparameter = '';
            var exogenousparameter = '';
            var shockparameter = '';
            $(xmlObj).find("rangeOptions").find("options").each(function (e) {

                 quesparameter += '<div class="rangeShell"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()).toFixed(2) + '" class="rhinput" title = "Parameters '+$(this).find("title").text()+' slider"><input class="baseChange" id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + $(this).find("value").text() + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + Number($(this).find("value").text()).toFixed(2) + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';

                sliderObjCounter++;
            });
            
            $("#Graph01 ." + $(xmlObj).find("rangeOptions").attr("id")).html(quesparameter);
            $(xmlObj).find("exogenousrange").find("options").each(function (e) {
                exogenousrangeparameter += '<div class="rangeShell"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()) + '" class="rhinput" title = "Exogenous '+$(this).find("title").text()+' slider"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + Number($(this).find("value").text()) + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + Number($(this).find("value").text()) + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("#Graph01 ." + $(xmlObj).find("exogenousrange").attr("id")).html(exogenousrangeparameter);
         
            var baselineUp = '';
            var baseline = '';
             baselineUp += '<div class="set set3"> <label><span class="italics">r</span><span class="separetor">= 7%</span></label></div><div class="set set5"> <label><span class="italics">r</span><span class="separetor">= 9%</span></label></div>'
            
            $(xmlObj).find("exogenousOptions").find("options").each(function (e) {
                baselineUp += '<div class="set set2"> <label for="' + $(this).find("title").text() + '" class="italics">' + $(this).find("title").text() + '</label><input type="text" disabled = "disabled" class="' + $(this).find("title").text() + '" value="'+$(this).find("minLimit").text()+'"></div>';
                baseline += '<div class="set set1"> <label><span class="italics">' + $(this).find("title").text() + '</span><span class="separetor">=</span><span class="baseline">'+$(this).find("minLimit").text()+'</span></label></div>';
            });
             exogenousparameter += '<div class="inputHolder">' + baselineUp + '</div>';
            exogenousparameter += '<div class="descHolder"><span class="descHolderHeader">Baseline</span>' + baseline + '</div>';
            $("#Graph01 ." + $(xmlObj).find("exogenousOptions").attr("id")).html(exogenousparameter);


        }
        $(".set1").eq(0).addClass("padingClass1");
        $(".set1").eq(1).addClass("padingClass2");
        
        $(".set1").eq(2).addClass("padingClass3");
        
        $(".set1").eq(3).addClass("padingClass4");
        $(".set2").eq(1).find("label").addClass("padingClass5");
        $(".set2").eq(3).find("label").addClass("padingClass5");
        
        /*souvik*/
        
        
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContentnew") {
           // alert(this._xmlObject.getElementsByTagName("rangeOptions"))
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[1].childNodes[1].textContent);
            var xmlObj = this._xmlObject;
            var quesparameter2 = '';
            var exogenousrangeparameter = '';
            var exogenousparameter = '';
            var shockparameter = '';
            $(xmlObj).find("rangeOptions2").find("options").each(function (e) {
                

                quesparameter2 += '<div class="rangeShell"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()).toFixed(2) + '" class="rhinput" title = "Parameters '+$(this).find("title").text()+' slider"><input class="baseChange" id="ex' + (sliderObjCounter+ 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' +$(this).find("value").text() + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + Number($(this).find("value").text()).toFixed(2) + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';

                sliderObjCounter++;
            });
            
            $("#Graph02 ." + $(xmlObj).find("rangeOptions2").attr("id")).html(quesparameter2);
            $(xmlObj).find("exogenousrange2").find("options").each(function (e) {

                exogenousrangeparameter += '<div class="rangeShell"><div class="rholder"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()).toFixed(2) + '" class="rhinput" title = "Exogenous '+$(this).find("title").text()+' slider"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + $(this).find("value").text()+ '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + $(this).find("value").text() + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';

                sliderObjCounter++;
            });
            $("#Graph02 ." + $(xmlObj).find("exogenousrange2").attr("id")).html(exogenousrangeparameter);
         
            var baselineUp = '';
            var baseline = '';
             baselineUp += '<div class="set set3"> <label><span class="italics">Y</span><span class="separetor">= 4500</span></label></div><div class="set set3"> <label><span class="italics">Y</span><span class="separetor">= 5500</span></label></div>'
            
            $(xmlObj).find("exogenousOptions2").find("options").each(function (e) {
                baselineUp += '<div class="set set2"> <label for="' + $(this).find("title").text() + '" class="italics">' + $(this).find("title").text() + '</label><input type="text" disabled = "disabled" class="' + $(this).find("title").text() + '" value="'+$(this).find("minLimit").text()+'"></div>';
                baseline += '<div class="set set4"> <label><span class="italics">' + $(this).find("title").text() + '</span><span class="separetor">=</span><span class="baseline">'+$(this).find("minLimit").text()+'</span></label></div>';
            });
             exogenousparameter += '<div class="inputHolder">' + baselineUp + '</div>';
            exogenousparameter += '<div class="descHolder"><span class="descHolderHeader descHolderHeader1">Baseline</span>' + baseline + '</div>';
            $("#Graph02 ." + $(xmlObj).find("exogenousOptions2").attr("id")).html(exogenousparameter);


        }
        
    }
    
    setTimeout(function () {
         $("svg").before("<span class = 'hiddenText1'>This is a Deriving IS LM Graph</span>");
        $("svg").attr("focusable","false");
        $("li > a").blur();
           $(".tab-pane").attr("role", "alert");
        }, 200);

     setTimeout(function(){$("#range1").attr("role","alert")},250);
    setTimeout(function(){$("#introHolder2").attr("role","alert")},250);
    
   
    this.Event();
};

macroModels.prototype.controlTab = function () {
    $("ul > li.active").children().attr("tabindex", "-1");
    
    $("ul > li").on("click",function () {

        setTimeout(function () {
            if ($("ul > li.active").children().attr("aria-expanded") == "true") {
                 //setTimeout(function(){alert(0);$("#jxgbox > svg").attr("tabindex","0").focus()},250)
                $("ul > li").children().removeAttr("tabindex");
                $("ul > li.active").children().attr("tabindex", "-1");
            }

        }, 250);
         setTimeout(function () {
           $(".tab-pane").attr("role", "alert");
        }, 500);
       

    });
};


/**
 * The Application On Ready Initialise. 
 * Create the Main Object Class.
 */

macroModels.prototype.Event = function () {
    var parameter = false;
    //question parameter click && parameter back click
    $(".param,.introback").off("click").on("click", function () {
       
     if($("ul > li.active").children().attr("href") == "#Graph02"){
         setTimeout(function(){$("#range2").attr("role","alert")},800);  
     }  
         if($("ul > li.active").children().attr("href") == "#Graph01"){
         setTimeout(function(){$("#range1").attr("role","alert")},800);  
     }  
        parameter = !parameter;
        // Can add another method and properties
        if (parameter) {
            $(".introHolder").removeClass('elementShow').addClass('elementHide');
            $(".rangeholder").removeClass('elementHide').addClass('elementShow');
             setTimeout(function(){$("#range1").attr("role","alert")},250);        
        }
        else {
            $(".rangeholder").removeClass('elementShow').addClass('elementHide');
            $(".introHolder").removeClass('elementHide').addClass('elementShow');
            setTimeout(function(){$("#introHolder2").attr("role","alert")},250);
        }
    });
}


$(function () {
    Model = new macroModels();
    Model.LoadXML();
    demo.Init();
});

var Model;