
var demo = {};
var board;
demo.floating = {
    e: 0,
    y: 5000,
    c: 0,
    i: 0,
    nx: 0
}
demo.fixed = {
    money: 0,
    y: 0,
    c: 0,
    i: 0,
    nx: 0
}
demo.floatingGraph = {
    mpc: 0.75,
    iemd: -0.10,
    oemd: 1,
    iem: 2,
    exsnx: 380,
    govtspend: 1200,
    tax: 1200,
    rworld: 8,
    moneysupply: 750,
    cons: 0,
    invest: 0,
    netex: 0,
    moneyd: 0

}
demo.fixedGraph = {
    mpc: 0.75,
    iemd: -0.10,
    oemd: 1,
    iem: 2,
    exsnx: 380,
    govtspend: 1200,
    tax: 1200,
    rworld: 8,
    exrate: 750,
    cons: 0,
    invest: 0,
    netex: 0,
    moneyd: 0

}

//X Axis Value Conversion
var xValConvert = function (x) {
     var min =0;
    var max = 11000;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 11;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//Y Axis Value Conversion
var yValConvert = function (y) {
    var min = -4;
    var max = 6;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 10;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};


//X Axis Value Rev Conversion
var xValRevConvert = function (x) {
    var min = 0;
    var max = 11000;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 11;

    var xLinePoint = ((diff / maxSlide) * x);
    return min + xLinePoint;
};

//Y Axis Value Rev Conversion
var yValfixedConvert = function (y) {
   var min = 0;
    var max = 6;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 6;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};

//
//var getStaticIsXfromY = function(x){
//    //Graph scenario value;
//   return Number((-500-(userData.marginalPC)*(1000)+(((-3/(userData.intereseID)-1)/4+1)*4200-450*yValRevConvert(x))+1000)/(1-(userData.marginalPC)));
//}
//var getIsXfromY = function(x){
//    //Graph scenario value;
//   return Number((-500+(userData.investement)-(userData.consumption)-userData.marginalPC*userData.taxes+(((-3/(userData.intereseID)-1)/4+1)*4200-450*yValRevConvert(x))+userData.govtSpend)/(1-userData.marginalPC));
//}
//
//var generateIsXRange = function(){
//    for(var i=0; i<=8; i++){
//       userData.xStaticList[i] = xValConvert(getStaticIsXfromY(i));
//       userData.xList[i] = xValConvert(getIsXfromY(i));
//        userData.yStaticList[i] = i;
//    }
//    board.fullUpdate();
//}
demo.Init = function () {

    board = JXG.JSXGraph.initBoard('jxgbox', {
        boundingbox: [0, 10, 11, 0],
        axis: false,
        grid: false,
        withLabel: true,
        showCopyright: false,
        keepaspectratio: false,
        showNavigation: false


    });
   board.create('axis', [[0, 0], [20, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        withLabel: false,
        name: 'X',
        straightFirst: false,
        straightLast: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        label: {
            position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, 10]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: 'grey',
            majorHeight: 0}
    });
     board.create('axis', [[0, 0], [0, 10]],
            {name: 'y',
                withLabel: false,
                straightFirst: false,
                straightLast: false,
                firstArrow: false,
                lastArrow: false,
                strokeColor: '#606060',
                strokeWidth: 2,
                label: {
                    position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [10, 10]   // (in pixels)
                },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: 'grey',
                    majorHeight: 0}
            });
            
      board.create('line', [[function(){return xValConvert(demo.floating.y)}, 0], [function(){return xValConvert(demo.floating.y)}, 10]], {
        straightFirst: false,
        straightLast: false,
        name: "LM*'",
        withLabel: true,
        strokeWidth: 2,
        strokeColor: 'red',
        highlight: false,
        label: {offset: [10, 30],cssClass:'italics'},
        fixed: true});

    board.create('line', [[xValConvert(5000), 0], [xValConvert(5000), 10]], {
        straightFirst: false,
        straightLast: false,
        name: 'LM*',
        withLabel: true,
        strokeWidth: 2,
        strokeColor: '#606060',
        highlight: false,
        label: {offset: [10, 30],cssClass:'italics'},
        fixed: true});
    
     board.create('functiongraph', [function (x) {
            x= xValRevConvert(x);
          return yValConvert(1+((x-(3100+(x-5000)*demo.floatingGraph.mpc-(demo.floatingGraph.tax-1200)*demo.floatingGraph.mpc+demo.floatingGraph.cons)-(700+(demo.floatingGraph.rworld-8)/8*demo.floatingGraph.iem*700+demo.floatingGraph.invest)-demo.floatingGraph.govtspend)-demo.floatingGraph.netex)/demo.floatingGraph.exsnx);
        }, xValConvert(0),xValConvert(11000)], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        name: "IS*'",
        withLabel: true,
        strokeColor: 'red',
         label: {offset: [130, -50],cssClass:'italics'},
        highlight: false,
        fixed: true});
    
    
    board.create('functiongraph', [function (x) {
            x= xValRevConvert(x);
          return yValConvert(1+((x-(3100+(x-5000)*0.75-(1200-1200)*0.75+0)-(700+(8-8)/8*-1.5*700+0)-1200)-0)/-380);
        }, xValConvert(0),xValConvert(11000)], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        name: "IS*",
        withLabel: true,
        strokeColor: '#606060',
            label: {offset: [100, -80],cssClass:'italics'},
        highlight: false,
        fixed: true});
    
    
    
     board1 = JXG.JSXGraph.initBoard('jxgboxFixed', {
        boundingbox: [0, 6, 11, 0],
        axis: false,
        grid: false,
        withLabel: true,
        showCopyright: false,
        keepaspectratio: false,
        showNavigation: false


    });
   board1.create('axis', [[0, 0], [20, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        withLabel: false,
        name: 'X',
        straightFirst: false,
        straightLast: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        label: {
            position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, 10]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: 'grey',
            majorHeight: 0}
    });
     board1.create('axis', [[0, 0], [0, 10]],
            {name: 'y',
                withLabel: false,
                straightFirst: false,
                straightLast: false,
                firstArrow: false,
                lastArrow: false,
                strokeColor: '#606060',
                strokeWidth: 2,
                label: {
                    position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [10, 10]   // (in pixels)
                },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: 'grey',
                    majorHeight: 0}
            });
            
      board1.create('line', [[function(){return xValConvert(demo.fixed.y)}, 0], [function(){return xValConvert(demo.fixed.y)}, 10]], {
        straightFirst: false,
        straightLast: false,
        name: "LM*'",
        withLabel: true,
        strokeWidth: 2,
        strokeColor: 'red',
        highlight: false,
        label: {offset: [10, 40],cssClass:'italics'},
        fixed: true});

    board1.create('line', [[xValConvert(5000), 0], [xValConvert(5000), 10]], {
        straightFirst: false,
        straightLast: false,
        name: 'LM*',
        withLabel: true,
        strokeWidth: 2,
        strokeColor: '#606060',
        highlight: false,
        label: {offset: [10, 30],cssClass:'italics'},
        fixed: true});
    
     board1.create('functiongraph', [function (x) {
            x= xValRevConvert(x);
           return yValfixedConvert(1+((x-(3100+(x-5000)*demo.fixedGraph.mpc-(demo.fixedGraph.tax-1200)*demo.fixedGraph.mpc+demo.fixedGraph.cons)-(700+(demo.fixedGraph.rworld-8)/8*demo.fixedGraph.iem*700+demo.fixedGraph.invest)-demo.fixedGraph.govtspend)-demo.fixedGraph.netex)/demo.fixedGraph.exsnx);
        }, xValConvert(0),xValConvert(11000)], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        name: "IS*'",
        withLabel: true,
        strokeColor: 'red',
         label: {offset: [100, -80],cssClass:'italics'},
        highlight: false,
        fixed: true});
    
    
    board1.create('functiongraph', [function (x) {
            x= xValRevConvert(x);
             return yValfixedConvert(1+((x-(3100+(x-5000)*0.75-(1200-1200)*0.75+0)-(700+(8-8)/8*-1.5*700+0)-1200)-0)/-380);
        }, xValConvert(0),xValConvert(11000)], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        name: "IS*",
        withLabel: true,
        strokeColor: '#606060',
            label: {offset: [100, -80],cssClass:'italics'},
        highlight: false,
        fixed: true});
    
    
    $("#jxgbox > svg").attr("desc", "This is a Mundell Fleming Model graph");
    $("#jxgbox > svg").attr("title", "Graph");


    this.sliderSelection();
};


demo.sliderSelection = function () {
    $("input[id^='ex']").each(function () {
        $(this).initiateSlider();
    });
};

$.fn.initiateSlider = function () {
    var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
            var vElmValue = value;
            vElmValue = (demo.getType(oThisElm.attr("data-slider-step")) === "float") ? Number(value).toFixed(2) : vElmValue;
            oThisElm.parent().parent().find(".rhinput").val(vElmValue);
            return 'Current value: ' + value;

        }
    });
    $("input[id^='ex']").slider().off().on('slideStop', function (ev, k) {
        demo.fieldUpdation();
      });
    demo.fieldUpdation();
};
demo.fieldUpdation = function () {

    demo.floatingGraph.mpc = Number($("#Graph01 .intro .rholder .rhinput")[0].value);
    demo.floatingGraph.iemd = Number($("#Graph01 .intro .rholder .rhinput")[2].value);
    demo.floatingGraph.oemd = Number($("#Graph01 .intro .rholder .rhinput")[4].value);
    demo.floatingGraph.iem = Number($("#Graph01 .intro .rholder .rhinput")[6].value);
    demo.floatingGraph.exsnx = Number($("#Graph01 .intro .rholder .rhinput")[8].value);
    demo.floatingGraph.govtspend = Number($("#Graph01 .block01 .rholder .rhinput")[0].value);
    demo.floatingGraph.tax = Number($("#Graph01 .block01 .rholder .rhinput")[2].value);
    demo.floatingGraph.rworld = Number($("#Graph01 .block01 .rholder .rhinput")[4].value);
    demo.floatingGraph.moneysupply = Number($("#Graph01 .block01 .rholder .rhinput")[6].value);
    demo.floatingGraph.cons = Number($("#Graph01 .block02 .rholder .rhinput")[0].value);
    demo.floatingGraph.invest = Number($("#Graph01 .block02 .rholder .rhinput")[2].value);
    demo.floatingGraph.netex = Number($("#Graph01 .block02 .rholder .rhinput")[4].value);
    demo.floatingGraph.moneyd = Number($("#Graph01 .block02 .rholder .rhinput")[6].value);


    demo.fixedGraph.mpc = Number($("#Graph02 .intro .rholder .rhinput")[0].value);
    demo.fixedGraph.iemd = Number($("#Graph02 .intro .rholder .rhinput")[2].value);
    demo.fixedGraph.oemd = Number($("#Graph02 .intro .rholder .rhinput")[4].value);
    demo.fixedGraph.iem = Number($("#Graph02 .intro .rholder .rhinput")[6].value);
    demo.fixedGraph.exsnx = Number($("#Graph02 .intro .rholder .rhinput")[8].value);
    demo.fixedGraph.govtspend = Number($("#Graph02 .block01 .rholder .rhinput")[0].value);
    demo.fixedGraph.tax = Number($("#Graph02 .block01 .rholder .rhinput")[2].value);
    demo.fixedGraph.rworld = Number($("#Graph02 .block01 .rholder .rhinput")[4].value);
    demo.fixedGraph.exrate = Number($("#Graph02 .block01 .rholder .rhinput")[6].value);
    demo.fixedGraph.cons = Number($("#Graph02 .block02 .rholder .rhinput")[0].value);
    demo.fixedGraph.invest = Number($("#Graph02 .block02 .rholder .rhinput")[2].value);
    demo.fixedGraph.netex = Number($("#Graph02 .block02 .rholder .rhinput")[4].value);
    demo.fixedGraph.moneyd = Number($("#Graph02 .block02 .rholder .rhinput")[6].value);



    demo.floating.y = Number((5000 + 5000 / demo.floatingGraph.oemd * (demo.floatingGraph.moneysupply - demo.floatingGraph.moneyd - 750) / 750 - 5000 * (demo.floatingGraph.rworld - 8) / 8 * demo.floatingGraph.iemd).toFixed(0));
    demo.floating.c = Number((3100 + (demo.floating.y - 5000) * demo.floatingGraph.mpc - (demo.floatingGraph.tax - 1200) * demo.floatingGraph.mpc + demo.floatingGraph.cons).toFixed(0));
    demo.floating.i = Number((700 + (demo.floatingGraph.rworld - 8) / 8 * demo.floatingGraph.iem * 700 + demo.floatingGraph.invest).toFixed(0));
    demo.floating.nx = demo.floating.y - demo.floating.c - demo.floating.i - demo.floatingGraph.govtspend;
    demo.floating.e = Number((1 + (demo.floating.nx - demo.floatingGraph.netex) / demo.floatingGraph.exsnx).toFixed(2));


    demo.fixed.nx = Number(((demo.fixedGraph.exrate - 1) * demo.fixedGraph.exsnx + demo.fixedGraph.netex).toFixed(0));
    demo.fixed.i = Number((700 + (demo.fixedGraph.rworld - 8) / 8 * demo.fixedGraph.iem * 700 + demo.fixedGraph.invest).toFixed(0));
    demo.fixed.y = Number(((demo.fixed.nx + demo.fixed.i + demo.fixedGraph.govtspend + 3100 - (demo.fixedGraph.tax - 1200) * demo.fixedGraph.mpc + demo.fixedGraph.cons - 5000 * demo.fixedGraph.mpc) / (1 - demo.fixedGraph.mpc)).toFixed(0));
    demo.fixed.money = Number((((demo.fixed.y - 5000 + 5000 * (demo.fixedGraph.rworld - 8) / 8 * demo.fixedGraph.iemd) * demo.fixedGraph.oemd / 5000 * 750) + 750 + demo.fixedGraph.moneyd).toFixed(0));
    demo.fixed.c = Number((3100 + (demo.fixed.y - 5000) * demo.fixedGraph.mpc - (demo.fixedGraph.tax - 1200) * demo.fixedGraph.mpc + demo.fixedGraph.cons).toFixed(0));

    demo.graphManupulation();
};

demo.graphManupulation = function () {
    $("#Graph01 #e").val(demo.floating.e);
    $("#Graph01 #Y").val(demo.floating.y);
    $("#Graph01 #C").val(demo.floating.c);
    $("#Graph01 #I").val(demo.floating.i);
    $("#Graph01 #NX").val(demo.floating.nx);

    $("#Graph02 #M").val(demo.fixed.money);
    $("#Graph02 #Y").val(demo.fixed.y);
    $("#Graph02 #C").val(demo.fixed.c);
    $("#Graph02 #I").val(demo.fixed.i);
    $("#Graph02 #NX").val(demo.fixed.nx);

    board.fullUpdate();
     board1.fullUpdate();
};

demo.getType = function (input) {
    var m = (/[\d]+(\.[\d]+)?/).exec(input);
    if (m) {
        // Check if there is a decimal place
        if (m[1]) {
            return 'float';
        }
        else {
            return 'int';
        }
    }
    return 'string';
}