
var demo = {};
var board;
var userData = {};
userData.marginalPC = 0.75; // 0.60 to 0.90
userData.interestEMD = -0.50; //-0.90 to -0.10
userData.outputEMD = 1; //0.80 to 1.20
userData.intereseID = -3; //-5.50 to -0.50
userData.moneySupply = 750; //650 to 850
userData.govtSpend = 1000; // 800 to 1200
userData.taxes = 1000; // 800 to 1200
userData.investement = 0; // -200 to 200
userData.consumption = 0; // -200 to 200
userData.moneyD = 0; // -100 to 100


userData.endogenousY = 5000;
userData.endogenousR = 8.00;
userData.endogenousI = 750;
userData.endogenousC = 3250;
userData.yStaticList=[0, 1, 2, 3, 4, 5, 6, 7];
userData.xStaticList=[41.000000000000036, 18.500000000000018, -3.999999999999982, -26.499999999999982, -48.99999999999999, -71.5, -94, -116.5, -139]
 userData.xList=[41.000000000000036, 18.500000000000018, -3.999999999999982, -26.499999999999982, -48.99999999999999, -71.5, -94, -116.5, -139]
//X Axis Value Conversion
var xValConvert = function (x) {
    var min = 4450;
    var max = 5500;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 21;

    var xLinePoint = ((maxSlide * (x - min)) / diff);
    return xLinePoint;
};

//Y Axis Value Conversion
var yValConvert = function (y) {
    var min = 0;
    var max = 12;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 12;

    var yLinePoint = ((maxSlide * (y - min)) / diff);
    return yLinePoint;
};


//X Axis Value Rev Conversion
var xValRevConvert = function (x) {
    var min = 4450;
    var max = 5500;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide =21;

    var xLinePoint = ((diff / maxSlide) * x);
    return min + xLinePoint;
};

//Y Axis Value Rev Conversion
var yValRevConvert = function (y) {
  var min = 0;
    var max = 12;
    var diff = max - min;
    var minSlide = 0;
    var maxSlide = 12;

    var yLinePoint = ((diff / maxSlide) * y);
    return min + yLinePoint;
};


var getStaticIsXfromY = function(x){
    
    //Graph scenario value;
   return Number((3250+0-(1000-1000)*userData.marginalPC+0+750+1000-5000*userData.marginalPC+(yValRevConvert(x)-8)*(userData.intereseID*750)/8)/(1-userData.marginalPC));
}
var getIsXfromY = function(x){
    
    //Graph scenario value;
   return Number((3250+userData.consumption-(userData.taxes-1000)*userData.marginalPC+userData.investement+750+userData.govtSpend-5000*userData.marginalPC+(yValRevConvert(x)-8)*(userData.intereseID*750)/8)/(1-userData.marginalPC));
}

var generateIsXRange = function(){
    for(var i=0; i<=12; i++){
       userData.xStaticList[i] = xValConvert(getStaticIsXfromY(i));
       userData.xList[i] = xValConvert(getIsXfromY(i));
        userData.yStaticList[i] = i;
    }
    board.fullUpdate();
}
demo.Init = function () {

    board = JXG.JSXGraph.initBoard('jxgbox', {
        axis: false,
        boundingbox: [0, 12, 21, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
  board.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        straightLast: true,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

  board.create('axis', [[0, 0], [0, 1]], {
        name: '',
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        lastArrow: false,
        withLabel: true,
                 label: {
                    position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [0, -180] // (in pixels)
                },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    board.create('curve', [userData.xList,userData.yStaticList], {
        strokeWidth: 1.5,
        strokeColor: 'red',
        highlight: false,
        fixed: true,
        name: "IS'",
        withLabel: true,
        label: {offset: [0, 15],cssClass:"italics"}
    });
   board.create('curve', [userData.xStaticList,userData.yStaticList], {
        strokeWidth: 1.5,
        strokeColor:'#606060',
        highlight: false,
        fixed: true,
        name: "IS",
        withLabel: true,
        label: {offset: [0, 15],cssClass:"italics"}
    });

    board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
              return yValConvert((x-(1+userData.interestEMD)*5000-(userData.moneySupply-userData.moneyD-750)*6.66666666666666)/(-625*userData.interestEMD)-(userData.outputEMD-1)*(0.8/-userData.interestEMD));
         }, xValConvert(4450), xValConvert(5500)], {
        strokeWidth: 1.5,
        strokeColor: 'red',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "LM'",
        withLabel: true,
        label: {offset: [0, 10],cssClass:"italics"}
    });

   board.create('functiongraph', [function (x) {
            x = xValRevConvert(x);
             return  yValConvert((x-(1+userData.interestEMD)*5000-(750-0-750)*6.66666666666666)/(-625*userData.interestEMD)-(userData.outputEMD-1)*(0.8/-userData.interestEMD));
        }, xValConvert(4450), xValConvert(5500)], {
        strokeWidth: 1.5,
        strokeColor: '#606060',
        straightFirst: false,
        straightLast: false,
        highlight: false,
        fixed: true,
        name: "LM",
        withLabel: true,
         label: {
             position: 'top',
             offset: [20, 10],cssClass:"italics"}
    });


    this.sliderChange();
};

demo.sliderChange = function () {

    $("input[id^='ex']").each(function () {
        $(this).initiateSlider();
    });
};

$.fn.initiateSlider = function () {
    var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
            var vElmValue = (parseInt(value) === value) ? value : value.toFixed(2);
            vElmValue = (demo.getType(oThisElm.attr("data-slider-value")) === "float") ?
                    Number(value).toFixed(2) : vElmValue;
            oThisElm.parent().parent().find(".rhinput").val(vElmValue);
             return 'Current value: ' + value;

        }
    });
     $("input[id^='ex']").slider().off().on('slideStop', function (ev, k) {
         demo.fieldUpdation();
    });
    demo.fieldUpdation();
};

demo.fieldUpdation = function () {
    $("svg").attr("focusable", "false");
    userData.marginalPC = Number($("#Graph01 .intro .rholder .rhinput")[0].value); // 0.60 to 0.90
    userData.interestEMD = Number($("#Graph01 .intro .rholder .rhinput")[2].value); //-0.90 to -0.10
    userData.outputEMD = Number($("#Graph01 .intro .rholder .rhinput")[4].value); //0.80 to 1.20
    userData.intereseID = Number($("#Graph01 .intro .rholder .rhinput")[6].value); //-5.50 to -0.50
    userData.moneySupply = Number($("#Graph01 .block01 .rholder .rhinput")[0].value); //650 to 850
    userData.govtSpend = Number($("#Graph01 .block01 .rholder .rhinput")[2].value); // 800 to 1200
    userData.taxes = Number($("#Graph01 .block01 .rholder .rhinput")[4].value); // 800 to 1200
    userData.investement = Number($("#Graph01 .block02 .rholder .rhinput")[0].value); // -200 to 200
    userData.consumption = Number($("#Graph01 .block02 .rholder .rhinput")[2].value); // -200 to 200
    userData.moneyD = Number($("#Graph01 .block02 .rholder .rhinput")[4].value); // -100 to 100


    userData.endogenousY = Number((((3250+ userData.consumption-(userData.taxes-1000)*userData.marginalPC+userData.investement+750+userData.govtSpend-5000*userData.marginalPC)-((userData.outputEMD-1)*(0.8/-userData.interestEMD))*((userData.intereseID*750)/8)-8*((userData.intereseID*750)/8)+(-(1+userData.interestEMD)*5000-(userData.moneySupply-userData.moneyD-750)*6.66666666666666)*((userData.intereseID*750)/8)/(-625*userData.interestEMD))/(1-userData.marginalPC-((userData.intereseID*750)/8)/(-625*userData.interestEMD))).toFixed(0));
    
    
   
    userData.endogenousC = Number((((userData.endogenousY-5000)*userData.marginalPC)+3250+userData.consumption-((userData.taxes-1000)*userData.marginalPC)).toFixed(0));
    userData.endogenousI = userData.endogenousY-userData.govtSpend-userData.endogenousC;
     userData.endogenousR = Number((8+(8/(userData.intereseID*750)*(userData.endogenousI-userData.investement-750))).toFixed(2));
    demo.graphManupulation();
};

demo.graphManupulation = function () {
    $("#Y").val(userData.endogenousY);
    $("#r").val(userData.endogenousR);
    $("#I").val(userData.endogenousI);
    $("#C").val(userData.endogenousC);
     generateIsXRange();
    board.fullUpdate();
};
demo.getType = function (input) {
    var m = (/[\d]+(\.[\d]+)?/).exec(input);
    if (m) {
        // Check if there is a decimal place
        if (m[1]) {
            return 'float';
        }
        else {
            return 'int';
        }
    }
    return 'string';
}