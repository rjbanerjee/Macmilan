
var demo = {};
var board;
var redLineIText = {
    x: 1.5,
    y: 3.2
};
var greyLineIText = {
    x: 1,
   y: 3.2
};
var IData=0;
var IData2=0;
var IDataFirst;
var IData2First;
var elasInv = -5, investment = 0, I = 950;
var greyLineI, greyLineS, redLineI, redLineS;
var graphConvert = function (g) {
    var lowVal = 400;
    var slidVal = g * 100 + lowVal;
    return slidVal;
};
var graphConvertRev = function (g) {
    var lowVal = 400;
    var slidVal = (g - lowVal) / 100;
    return slidVal;
};
var coordinatecheck = function (x, y) {
   // console.log(x,y);    
    var coordx = ((x >= 0) && (x <= 7)) ? true : false;
    var coordy = ((y >= 0) && (y <= 4)) ? true : false;
    var coordbool = ((coordx) && (coordy)) ? true : false;
    return coordbool;
};
// Red line calculation done here based on slider value change
var LineCalRed = function(x){
     IData2 = ((8 + (8 / (elasInv * 750) * (graphConvert(x) - investment - 750)) - 6) > 0) ? 0:(0-((8 + (8 / (elasInv * 750) * (graphConvert(x) - investment - 750)) - 6)));
   return ((8 + (8 / (elasInv * 750) * (graphConvert(x) - investment - 750)) - 6) > 0) ? (8 + (8 / (elasInv * 750) * (graphConvert(x) - investment - 750)) - 6) : 0;
};
// Gray line calculation done here based on slider value change
var LineCalGrey = function(x){
    IData = ((8 + (8 / (elasInv * 750) * (graphConvert(x) - 750)) - 6) > 0)? 0 :(0-(8 + (8 / (elasInv * 750) * (graphConvert(x) - 750)) - 6)) ;
  return ((8 + (8 / (elasInv * 750) * (graphConvert(x) - 750)) - 6) > 0) ? (8 + (8 / (elasInv * 750) * (graphConvert(x) - 750)) - 6) : 0;
};

demo.Init = function () {
    //Board creation
    board = JXG.JSXGraph.initBoard('jxgbox', {
        boundingbox: [-1, 4, 8, -1],
        axis: false,
        grid: false,
        withLabel: false,
        showCopyright: false,
        keepaspectratio: false,
        showNavigation: false
        
        
    });
    //X-axis creation
    var xaxis = board.create('axis', [[0, 0], [8, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        withLabel: false,
        name: 'X',
        straightFirst: false,
        straightLast: false,
        strokeColor: '#606060',
        strokeWidth: 2,
        label: {
            position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-20, 10]   // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: 'grey',
            majorHeight: 0}
    });
    //Y-axis creation
    var yaxis = board.create('axis', [[0, 0], [0, 10]],
            {name: 'y',
                withLabel: false,
                straightFirst: false,
                straightLast: false,
                firstArrow: false,
                lastArrow: false,
                strokeColor: '#606060',
                strokeWidth: 2,
                label: {
                    position: 'rt', // possible values are 'lft', 'rt', 'top', 'bot'
                    offset: [10, 10]   // (in pixels)
                },
                ticks: {
                    drawLabels: false,
                    fixed: true,
                    strokeOpacity: 0,
                    strokeWidth: 0,
                    strokeColor: 'grey',
                    majorHeight: 0}
            });
    //Labels creation for the whole Graph
    var text1 = board.create('text', [-.2, -.1, "400"]);
    var text2 = board.create('text', [7, -.1, "1100"]);
    var text3 = board.create('text', [3, -.1, "I, S ($ billion)"], {cssClass:'italics'});
    var text4 = board.create('text', [-.7, 0.2, "6.00"]);
    var text5 = board.create('text', [-.9, 4, "10.00"]);
    var text6 = board.create('text', [-.7, 2, "r (%)"], {cssClass:'italics'});
    redLineI = board.create('functiongraph', [function (x) {
            return LineCalRed(x);
        }, 0, function(){
            return (7-IData2);
        }], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        strokeColor: '#606060',
        highlight: false,
        fixed: true});
    greyLineI = board.create('functiongraph', [function (x) {
         return LineCalGrey(x);
        }, 0, function(){
            return (7-IData);
        }], {
        straightFirst: false,
        straightLast: false,
        strokeWidth: 1.5,
        strokeColor: '#606060',
        highlight: false,
        fixed: true});
     var text7 = board.create('text', [function () {
            return greyLineIText.x;
        },function () {
            return greyLineIText.y;
        },"I"], {cssClass:'italics'});
    
    var text7 = board.create('text', [function () {
            return redLineIText.x;
        },function () {
            return redLineIText.y;
        },"I'"], {cssClass:'italics'});
    redLineS = board.create('line', [[function (x) {
                if (graphConvertRev(I) >= 0) {
                    return graphConvertRev(I);
                }
                else {
                    return -2;
                }
            }, 0], [function (x) {
                if (graphConvertRev(I) >= 0) {
                    return graphConvertRev(I)
                }
                else {
                    return -2;
                }
            }, 8]], {
        straightFirst: false,
        straightLast: false,
        name: "S'",
        withLabel: true,
        strokeWidth: 2,
        highlight: false,
        label: {offset: [10, 30],cssClass:"italics"},
        strokeColor: 'red',
        fixed: true});
    // GreyLine S
    greyLineS = board.create('line', [[3.5, 0], [3.5, 8]], {
        straightFirst: false,
        straightLast: false,
        name: 'S',
        withLabel: true,
        strokeWidth: 2,
        strokeColor: '#606060',
        highlight: false,
        label: {offset: [10, 30],cssClass:"italics"},
        fixed: true});

    //$("#jxgbox > svg").attr("desc","This is a Equilibriam interest rate graph");
    $("#jxgbox > svg").attr("title","Graph");
    

    this.sliderSelection();
     this.boardUpdation();
};

// calling the init function for all the sliders of the page.    
demo.sliderSelection = function () {
    $("input[id^='ex']").each(function () {
        $(this).initiateSlider();
    });
};
// Init function for all the sliders of the page.  
$.fn.initiateSlider = function () {
    var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
            var vElmValue = (parseInt(value) === value) ? value : value.toFixed(2);
            oThisElm.parent().parent().find(".rhinput").val(vElmValue);
            demo.fieldUpdation();
            return 'Current value: ' + value;
            
        }
    });
};
// Baseline value field updation done here at slider value change
demo.fieldUpdation = function () {
    $(".intro .rholder .rhinput")[2].value = Number($(".intro .rholder .rhinput")[2].value).toFixed(2);
    //endogenoues consumption calculation
    $("#C").val(Math.round(((Number($(".block01 .rholder .rhinput")[0].value) - 5000) * Number($(".intro .rholder .rhinput")[1].value)) + 3250 + Number($(".block02 .rholder .rhinput")[3].value) - ((Number($(".block01 .rholder .rhinput")[4].value) - 1000) * Number($(".intro .rholder .rhinput")[1].value))));
    //endogenoues investment calculation
    $("#I").val(Math.round(Number($(".block01 .rholder .rhinput")[0].value) - Number($(".block01 .rholder .rhinput")[2].value) - Number($("#C").val())));
    //endogenoues investment calculation
    $("#r").val((8 + (8 / (Number($(".intro .rholder .rhinput")[2].value) * 750) * (Number($("#I").val()) - Number($(".block02 .rholder .rhinput")[0].value) - 750))).toFixed(2));
    demo.graphManupulation();
};
demo.graphCal = {};
demo.graphCal.calY = function (rawY) {
    var yDiff = 6;
    return rawY - yDiff;
}

demo.graphCal.GLI = function (left) {
    var elasInv = Number($(".intro .rholder .rhinput")[2].value);
    return 8 + (8 / (elasInv * 750) * (left - 750));
};
demo.graphCal.RLI = function (left) {
    var marProCons = Number($(".intro .rholder .rhinput")[2].value);
    var investment = Number($(".block02 .rholder .rhinput")[1].value);
    return 8 + Math.abs(8 / (marProCons * 750) * (left - investment - 750));
};
demo.graphManupulation = function () {
    elasInv = Number($(".intro .rholder .rhinput")[2].value);
    investment = Number($(".block02 .rholder .rhinput")[1].value);
    I = Number($("#I").val());
    board.fullUpdate();
};
// Graph Board updation 
demo.boardUpdation =function (){
    board.on('update', function () {
   //  console.log(LineCalRed(0),LineCalRed(3.5),LineCalRed(7));
     
     //console.log("adasds")
     // console.log(LineCalGrey(0),LineCalGrey(3.5),LineCalGrey(7));
      demo.boardConfirm();
});
};
// Lines of Graph board updation
 demo.boardConfirm = function(){
      if (coordinatecheck(0,LineCalGrey(0))){
           //console.log(LineCalGrey(0));
          greyLineIText.x = 1,greyLineIText.y = LineCalGrey(0);
      }
        else if(coordinatecheck(7,LineCalGrey(7))){
            //console.log(2);
               greyLineIText.x = 4,greyLineIText.y = (LineCalGrey(3.5));
            //greyLineIText.x = 6.5,greyLineIText.y = LineCalGrey(7);
        }
        else{
            //console.log(1);
            greyLineIText.x = 4,greyLineIText.y = (LineCalGrey(3.5));
        }
         if (coordinatecheck(0,LineCalRed(0))){
           //console.log(LineCalGrey(0));
          redLineIText.x = 1.5,redLineIText.y = LineCalRed(0);
      }
        else if(coordinatecheck(7,LineCalRed(7))){
            //console.log(2);
               redLineIText.x = 4.5,redLineIText.y = (LineCalRed(3.7));
            //greyLineIText.x = 6.5,greyLineIText.y = LineCalGrey(7);
        }
        else{
            //console.log(1);
            redLineIText.x = 4.5,redLineIText.y = (LineCalRed(3.5));
        }
 };