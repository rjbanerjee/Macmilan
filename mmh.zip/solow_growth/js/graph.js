var demo = {};
var board;
var count = 0;
//X Axis Value Conversion
var xValConvert = function (x) {
    var min = 1990;
    var xLinePoint = (x - min);
    return xLinePoint;
};


//X Axis Value Rev Conversion
var xValRevConvert = function (x) {
    var min = 1990;
    var max = 2080;
//    var diff = max - min;
//    var minSlide = 0;
//    var maxSlide = 85;
    var xLinePoint = min + x;
    return xLinePoint;
};


demo.Init = function () {

    board = JXG.JSXGraph.initBoard('box', {
        axis: false,
        boundingbox: [-7, 25, 90, 0],
        grid: false,
        keepaspectratio: false,
        showCopyright: false,
        showNavigation: false
    });
    var xaxis = board.create('axis', [[0, 0], [1, 0]], {
        needsRegularUpdate: false,
        firstArrow: false,
        lastArrow: false,
        highlightStrokeWidth: 1,
        withLabel: true,
        name: '',
        straightFirst: false,
        straightLast: true,
        strokeColor: '#4C4C4C',
        strokeWidth: 3,
        label: {
            position: 'lt', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [135, -25] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });

    var yaxis = board.create('axis', [[0, 0], [0, 1]], {
        name: 'y',
        withLabel: false,
        straightFirst: false,
        straightLast: true,
        firstArrow: false,
        lastArrow: false,
        strokeColor: '#4C4C4C',
        strokeWidth: 2,
        label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [0, -180] // (in pixels)
        },
        ticks: {
            drawLabels: false,
            fixed: true,
            strokeOpacity: 0,
            strokeWidth: 0,
            strokeColor: '#008000',
            majorHeight: 0
        }
    });
    var t1 = board.create('text', [-6.5, 25, "25.00"]);
    var t2 = board.create('text', [-5, 15, "y, c"],{cssClass:'italics'});
    var t3 = board.create('text', [-5, 1.5, "0.00"]);
    var consumption = board.create('curve', [dataX, dataConsumptionY], {strokeColor: 'blue', name: "C", strokeWidth: 1.5, fixed: true,highlight:false, withLabel: true, label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
            offset: [-180, 20] // (in pixels)
            ,cssClass:'italics'
        }});
    var output = board.create('curve', [dataX, dataOutputY], {strokeColor: 'red', name: "Y",highlight:false, strokeWidth: 1.5, fixed: true, withLabel: true, label: {
            position: 'bot', // possible values are 'lft', 'rt', 'top', 'bot'
           offset: [-180, 0] // (in pixels)
           ,cssClass:'italics'
        }});

    this.sliderChange();
};

demo.sliderChange = function () {

    $("input[id^='ex']").each(function () {
        $(this).initiateSlider();
    });
};

$.fn.initiateSlider = function () {
    var oThisElm = this;
    var that = (oThisElm.selector.length > 0) ? oThisElm.selector : oThisElm.context;
    var slider = new Slider(that, {
        formatter: function (value) {
            var vElmValue = value.toFixed(2);
            oThisElm.parent().parent().find(".rhinput").val(vElmValue);
            return 'Current value: ' + value;

        }
    });
    $("input[id^='ex']").slider().off().on('slideStop', function (ev, k) {
        $('.graphOverlay').fadeIn(400, function () {
            demo.fieldUpdation();
            macroModels.prototype.updateTable();
        });
        $('.graphOverlay').fadeOut(400);
    });


    demo.fieldUpdation();
};

demo.fieldUpdation = function () {
    $("svg").attr("focusable", "false");
    $("table tr").eq(1).find("td").eq(1).text(Number(Math.pow((Number($(".block01 .rholder .rhinput")[0].value) / (Number($(".intro .rholder .rhinput")[0].value) + Number($(".block02 .rholder .rhinput")[0].value))), (1 / (1 - Number($(".intro .rholder .rhinput")[2].value))))).toFixed(2));
    $("table tr").eq(4).find("td").eq(1).text(Number(Math.pow((Number($(".block01 .rholder .rhinput")[2].value) / (Number($(".intro .rholder .rhinput")[0].value) + Number($(".block02 .rholder .rhinput")[2].value))), (1 / (1 - Number($(".intro .rholder .rhinput")[2].value)))) * (1 + (Number($(".block03 .rholder .rhinput")[0].value)))).toFixed(2));
    macroModels.prototype.updateTable();
};

demo.graphManupulation = function () {
    board.fullUpdate();
};
  