/**
 * Main _Contructor Function of this Application.
 */
function macroModels() {
    this._xmlFileName = "Activity.xml";
    this._xmlFilePath = "./xml/";
    this._xmlObject = null;
    this._activityTitle = null;
}

/**
 * Function Loads the Macromodel Activity XML from the configured parameters in _Constructor.
 * The Function Store the XML Object in the Defined Variable in _Constructor.
 */
macroModels.prototype.LoadXML = function () {
    //Loading XML File.
    this._xmlObject = loadXMLDoc(this._xmlFilePath + this._xmlFileName);
    //Parsing XML String.
    this._xmlObject = parseXMLString(this._xmlObject);
    //The Main DOM is been added in Object.
    this._xmlObject = this._xmlObject.getElementsByTagName("activity")[0];
    this.GenerateHTML();
    this.controlTab();
}

/**
 * [[Description]]
 */


macroModels.prototype.GenerateHTML = function () {
    // stri  
    //Title Name
    this._activityTitle = this._xmlObject.getElementsByTagName("heading")[0].childNodes[0].nodeValue;
    $("title").html(this._activityTitle);
    $(".modelTitle a").html(this._activityTitle);
    $(".questionHolder p").html(this._xmlObject.getElementsByTagName("question")[0].childNodes[0].nodeValue);
    var _activityTabs = this._xmlObject.getElementsByTagName("section");
    var _activityTabsCount = this._xmlObject.getElementsByTagName("section").length;

    for (i = 0; i < _activityTabsCount; i++) {
        $(".nav li:eq(" + i + ") a").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "content") {
            //$(".tab-pane :eq(" + i + ") h3").html(this._xmlObject.getElementsByTagName("section")[i].getAttribute("title"));

            $(".tab-pane :eq(" + i + ") p").html(this._xmlObject.getElementsByTagName("section")[0].childNodes[1].textContent);
        }
        if (this._xmlObject.getElementsByTagName("section")[i].getAttribute("type") === "graphContent") {
//                    console.log(this._xmlObject.getElementsByTagName("rangeOptions").childNodes)
//                      var _activityQestionRangeCount = this._xmlObject.getElementsByTagName("rangeOptions");
//                      alert(_activityQestionRangeCount[0].getElementsByTagName("options").length); 
            $(".introHolder .CH-Content p").html(this._xmlObject.getElementsByTagName("section")[1].childNodes[1].textContent);
            var xmlObj = this._xmlObject;
            var sliderObjCounter = 0;
            var quesparameter = '';
            var exogenousrangeparameter = '';
            var exogenousparameter = '';
            var shockparameter = '';
            $(xmlObj).find("rangeOptions").find("options").each(function (e) {
                quesparameter += '<div class="rangeShell"><div class="rholder" id = "title' + (e + 1) + '" aria-labeldby = "' + $(this).find("title").text() + '"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()).toFixed(2) + '" class="rhinput" title = "Parameters ' + $(this).find("title").text() + 'slider"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + Number($(this).find("value").text()) + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + Number($(this).find("value").text()) + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("." + $(xmlObj).find("rangeOptions").attr("id")).html(quesparameter);
            $(xmlObj).find("exogenousrange").find("options").each(function (e) {
                exogenousrangeparameter += '<div class="rangeShell"><div class="rholder" id = "title' + (e + 1) + '" aria-labeldby = "' + $(this).find("title").text() + '"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()) + '" class="rhinput" title = "Saving Rate (%) ' + $(this).find("title").text() + 'slider"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider"  type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + Number($(this).find("value").text()) + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + Number($(this).find("value").text()) + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("." + $(xmlObj).find("exogenousrange").attr("id")).html(exogenousrangeparameter);
            $(xmlObj).find("shockRange").find("options").each(function (e) {
                shockparameter += '<div class="rangeShell"><div class="rholder" id = "title' + (e + 1) + '" aria-labeldby = "' + $(this).find("title").text() + '"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()) + '" class="rhinput" title = "Population Growth (%) ' + $(this).find("title").text() + 'slider"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider" type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + Number($(this).find("value").text()) + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + Number($(this).find("value").text()) + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
                sliderObjCounter++;
            });
            $("." + $(xmlObj).find("shockRange").attr("id")).html(shockparameter);
            $(xmlObj).find("exogenousOptions").find("options").each(function (e) {
                exogenousparameter += '<div class="rangeShell"><div class="rholder" id = "title' + (e + 1) + '" aria-labeldby = "' + $(this).find("title").text() + '"><h5>' + $(this).find("title").text() + '<span class = "hiddenText">Slider</span></h5></div><div class="rholder"><input type="text" disabled = "disabled" value="' + Number($(this).find("value").text()) + '" class="rhinput" title = "Shocks To ' + $(this).find("title").text() + 'slider"><input id="ex' + (sliderObjCounter + 1) + '" data-slider-id="ex' + (e + 1) + 'Slider"  type="text" data-slider-min="' + $(this).find("minLimit").text() + '" data-slider-max="' + $(this).find("maxLimit").text() + '" data-slider-step="' + $(this).find("stepLimit").text() + '" data-slider-value="' + Number($(this).find("value").text()) + '" data-slider-tooltip="hide"/></div><div class="rholder last col-sm-4"><span class="minRange">' + $(this).find("minLimit").text() + '</span><span class="minRange rhinput">' + Number($(this).find("value").text()) + '</span><span class="maxRange">' + $(this).find("maxLimit").text() + '</span></div></div>';
            });
            $("." + $(xmlObj).find("exogenousOptions").attr("id")).html(exogenousparameter);


        }
    }
    $(".controlSection").hide();
    
    setTimeout(function () {
        $("svg").before("<span class = 'hiddenText1'>This is a Model of Solow Growth Graph</span>");
        $("svg").attr("focusable", "false");
        $("li > a").blur();
        $(".tab-pane").attr("role", "alert");
         //$(".tab-pane").attr("tabindex", "0").focus();
    }, 200);
    setTimeout(function () {
        $(".controlSection").attr("tabindex","0").focus();
    }, 8000);
    
    
    this.Event();
};
macroModels.prototype.controlTab = function () {
     $("ul > li.active").children().attr("tabindex", "-1");

    $("ul > li").on("click", function () {
      
    // Can add another method and properties
        if ($(this).index() !== 0) {
            $(".controlSection").show();
        } else {
            $(".controlSection").hide();
        }
        setTimeout(function () {
            if ($("ul > li.active").children().attr("aria-expanded") == "true") {
                //setTimeout(function(){alert(0);$("#jxgbox > svg").attr("tabindex","0").focus()},250)
                $("ul > li").children().removeAttr("tabindex");
                $("ul > li.active").children().attr("tabindex", "-1");
                if($("ul > li.active").children().attr("href") == "Graph01"){
                    $(".controlSection").attr("role","alert");
                }
            }

        }, 250);
        setTimeout(function () {
            $(".tab-pane").attr("role", "alert");
        }, 500);
        setTimeout(function () {
             $(".controlSection").attr("tabindex","0").focus();
        }, 5000);


    });
};

/**
 * The Application On Ready Initialise. 
 * Create the Main Object Class.
 */

macroModels.prototype.Event = function () {
    var parameter = false;
    //question parameter click && parameter back click
    $(".param,.introback").off("click").on("click", function () {
        parameter = !parameter;
        // Can add another method and properties
        if (parameter) {
            $(".introHolder").removeClass('elementShow').addClass('elementHide');
            $(".rangeholder").removeClass('elementHide').addClass('elementShow');
            $(".introback").attr("tabIndex", "0").focus();
            $(".rangeholder").removeAttr("aria-hidden", "false");
            /*$(".rangeholder").find(".introback").attr({"tabindex": "0","aria-hidden":"false"});
             $(".rangeholder").find(".introback").removeAttr("disabled","disabled");*/
            setTimeout(function () {
                $(".rangeholder").attr("role", "alert")
            }, 250);
        }
        else {
            $(".rangeholder").removeClass('elementShow').addClass('elementHide');
            $(".introHolder").removeClass('elementHide').addClass('elementShow');
            $(".param").attr("tabIndex", "0").focus();
            /* $(".rangeholder").find(".introback").attr({"tabindex": "-1","aria-hidden":"true"});
             $(".rangeholder").find(".introback").attr("disabled","disabled");*/
            setTimeout(function () {
                $(".introHolder").attr("role", "alert")
            }, 250);
        }
    });
    macroModels.prototype.createTable();
}
macroModels.prototype.createTable = function () {
    var table = '';
    var header = ['Year', 'Capital', 'Output', 'Consump', 'Invest', 'Deprec', 'MPK'];
    var startYear = 2015;
    var yearIncreaser = 0;
    if ($('#table').find("table").length > 0) {
        table = $('#table').find("table");
    } else {
        table = $('<table></table>');
    }

    for (var i = 0; i <= 62; i++) {
        var row = $('<tr></tr>');
        for (var j = 0; j < 7; j++) {
            var column;

            if (i === 0) {
                column = $('<th></th>').text(header[j]);
            }
            else {
                if (j === 0) {
                    column = $('<td></td>').text(startYear + (yearIncreaser - 1));
                }
                else {
                    column = $('<td class="' + header[j].toLowerCase() + '"></td>').text(i + j);
                }
            }
            table.append(row);
            row.append(column);
        }

        yearIncreaser++;
    }
    $('#table').html(table);
};
var dataX = [], dataConsumptionY = [], dataOutputY = [];
macroModels.prototype.updateTable = function () {
    $("#table .capital").each(function (e) {

        //capital field
        if ((e !== 0) && (e !== 3)) {
            $("#table .capital").eq(e).text((Number($("#table .capital").eq(e - 1).text()) + Number($("#table .invest").eq(e - 1).text()) - Number($("#table .Deprec").eq(e - 1).text())).toFixed(2));
        }

        //output field
        $("#table .output").eq(e).text(Math.pow(Number($("#table .capital").eq(e).text()), Number($(".intro .rholder .rhinput")[2].value)).toFixed(2));

        //consump field
        if (e < 3) {
            $("#table .consump").eq(e).text((Number($("#table .output").eq(e).text()) * (1 - Number($(".block01 .rholder .rhinput")[0].value))).toFixed(2));
        }
        else {
            $("#table .consump").eq(e).text((Number($("#table .output").eq(e).text()) * (1 - Number($(".block01 .rholder .rhinput")[2].value))).toFixed(2));
        }

        //invest field
        $("#table .invest").eq(e).text((Number($("#table .output").eq(e).text()) - Number($("#table .consump").eq(e).text())).toFixed(2));

        //deprec field
        $("#table .deprec").eq(e).text((Number($("#table .capital").eq(e).text()) * Number($(".intro .rholder .rhinput")[0].value)).toFixed(2));

        //mpk field
        $("#table .mpk").eq(e).text((Number($("#table .output").eq(e).text()) / Number($("#table .capital").eq(e).text()) * Number($(".intro .rholder .rhinput")[2].value)).toFixed(3));

        dataConsumptionY[e] = Number($("#table .consump").eq(e).text());
        dataOutputY[e] = Number($("#table .output").eq(e).text());
        dataX[e] = e + 25;
    });
    demo.graphManupulation();
};
$(function () {
    Model = new macroModels();
    Model.LoadXML();
    demo.Init();
});

var Model;